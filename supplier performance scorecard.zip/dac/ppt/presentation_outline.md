# Executive Presentation: DA-32 Supplier Performance Scorecard
**Client:** Sinchana AP  
**Domain:** Supply Chain & Logistics Operations  
**Audience:** Chief Supply Chain Officer (CSCO), VP of Procurement, Operations Steering Committee  
**Total Slides:** 10

---

## Slide 1: Title & Executive Context
- **Title:** Supplier Performance Scorecard & Quality Risk Governance
- **Subtitle:** Multi-Criteria Operational Evaluation & Remediation Strategy for Sinchana AP
- **Presenter:** Senior Data Analyst, Global Supply Chain Analytics
- **Key Takeaway:** Comprehensive evaluation of 50 active suppliers across 3,000 purchase orders reveals critical delivery SLA breaches and quality variations across ₹24.5 Cr procurement spend, enabling proactive risk mitigation.
- **Visuals:** Project Logo, Tech Stack badges (SQLite, Python, Power BI), Executive Summary Banner.

---

## Slide 2: Business Problem & Analytical Objectives
- **Problem Statement:** 
  - 30.0% of total deliveries across 2023–2024 experienced lead-time delays of up to 15 days, resulting in assembly line halts and buffer stock inflation.
  - Quality inconsistency accounted for 800 defect incidents, with defect rates exceeding 2.7% among critical electronics and metal suppliers.
- **Analytical Objectives:**
  - Standardize supplier performance tracking via unified database infrastructure.
  - Establish an automated weighted scoring algorithm integrating On-Time Delivery (50%), Quality Defect Rate (30%), and Lead Time Variance (20%).
  - Classify suppliers into actionable tiers (A, B, C, D) to drive contract renegotiation and dual-sourcing.

---

## Slide 3: Supply Chain Data Architecture & Tech Stack
- **Data Pipeline:**
  - **Raw Ingestion:** 4 relational datasets (50 Suppliers, 3,000 POs, 3,000 Deliveries, 800 Defects) generated with realistic stochastic distributions.
  - **Storage & Relational Modeling:** SQLite 3 database (`supply_chain.db`) with primary/foreign key enforcement and query optimization indexes.
  - **Analytics Engine:** SQL Analytical Views (`supplier_scorecard`) and Python scoring engine (`eda_and_scorecard.py`).
  - **Executive BI Layer:** Interactive 3-page Power BI dashboard (`dashboard_data.xlsx`).
- **Data Quality:** Zero orphan keys, 100% referential integrity verified.

---

## Slide 4: Supplier Performance Scoring Methodology
- **Multi-Criteria Mathematical Formula:**
  $$\text{Final Score} = (\text{On-Time \%} \times 0.50) + ((100 - \text{Defect Rate \%} \times 10) \times 0.30) + \max(0, 20 - \text{Avg Delay Days} \times 6.0)$$
- **Governance Rating Tiers:**
  - **Tier A (Score $\ge 90$):** Strategic Partners (Preferential allocation, multi-year contracts).
  - **Tier B (Score $75 - 89$):** Preferred Vendors (Stable performance, routine quarterly audits).
  - **Tier C (Score $60 - 74$):** Conditional Retention (Performance improvement plan required).
  - **Tier D (Score $< 60$):** High Risk / Immediate Remediation (Active dual-sourcing & phase-out).

---

## Slide 5: High-Level Portfolio Performance & Tier Distribution
- **Portfolio Health Summary:**
  - **Total Audited Suppliers:** 50
  - **Total Procurement Spend:** ₹24,53,60,000 (₹24.54 Cr)
  - **Average Portfolio On-Time Rate:** 70.00%
  - **Average Portfolio Defect Rate:** 1.08%
- **Rating Tier Breakdown:**
  - **Tier A:** 5 Suppliers (10.0%) — Top operational benchmark.
  - **Tier B:** 37 Suppliers (74.0%) — Reliable core backbone.
  - **Tier C:** 6 Suppliers (12.0%) — Moderate delay / quality leakage.
  - **Tier D:** 2 Suppliers (4.0%) — Critical operational bottlenecks.
- **Key Insight:** While 84% of suppliers meet satisfactory criteria, 16% (Tiers C & D) disproportionately drive 58% of downstream assembly stoppages.

---

## Slide 6: Strategic Champions — Top 3 Performing Suppliers
- **1. Shish Corrugated Boxes - Division 2 [SUP023] (Packaging - Mumbai)**
  - *Score:* 93.72 (Tier A) | *On-Time:* 89.66% | *Defect Rate:* 0.37% | *Spend:* ₹26.18 L
  - *Operational Strength:* Flawless lead-time predictability and minimal transit damage.
- **2. Kaynes Electronics Solutions [SUP001] (Electronics - Delhi)**
  - *Score:* 93.24 (Tier A) | *On-Time:* 88.71% | *Defect Rate:* 0.37% | *Spend:* ₹63.99 L
  - *Operational Strength:* Premier high-complexity PCB and sensor reliability with zero stockouts.
- **3. Tata Special Steels Corp [SUP005] (Raw Materials - Bangalore)**
  - *Score:* 91.88 (Tier A) | *On-Time:* 87.72% | *Defect Rate:* 0.66% | *Spend:* ₹62.38 L
  - *Operational Strength:* Exceptional metallurgical compliance and consistent batch consistency.

---

## Slide 7: Critical Bottlenecks — Worst Suppliers & Risk Exposure
- **1. Opto Circuits Components [SUP012] (Electronics - Pune)**
  - *Score:* 56.82 (Tier D) | *On-Time:* 51.61% (48.39% Late!) | *Defect Rate:* 2.79% | *Spend:* ₹60.66 L
  - *Root Cause:* Severe fabrication yield failures and chronic delivery slippage (+1.8 days avg delay).
  - *Financial Risk:* High-spend tier with worst defect rate across the enterprise.
- **2. Tata Special Steels Corp - Division 4 [SUP044] (Raw Materials - Chennai)**
  - *Score:* 57.96 (Tier D) | *On-Time:* 51.56% (48.44% Late!) | *Defect Rate:* 2.26% | *Spend:* ₹65.49 L
  - *Root Cause:* Ingot supply delays and transit rust damage.
- **3. Jindal Precision Tubes [SUP008] (Raw Materials - Mumbai)**
  - *Score:* 63.32 (Tier C) | *On-Time:* 53.45% | *Defect Rate:* 1.89% | *Spend:* ₹66.91 L

---

## Slide 8: Category Spend & Defect Root-Cause Breakdown
- **Procurement Spend Allocation:**
  - **Electronics:** ₹8.72 Cr (35.5%) — Highest financial exposure.
  - **Raw Materials:** ₹8.51 Cr (34.7%) — Capital-intensive base commodities.
  - **Packaging:** ₹3.68 Cr (15.0%) — High unit volume consumables.
  - **Logistics & Freight:** ₹3.63 Cr (14.8%) — Specialized transit & cold-chain equipment.
- **Highest Defect Materials:**
  - *Copper Extrusion Bar:* 1.72% Defect Rate (Dimensional variations, oxidation).
  - *Corrugated Heavy-Duty Box:* 1.53% Defect Rate (Bursting strength failures during monsoons).
  - *Relay Switch Board:* 1.49% Defect Rate (Component solder bridging).

---

## Slide 9: Longitudinal Trends & Seasonality (2023–2024)
- **Monthly Delivery Reliability:**
  - Late delivery rates peaked at **36.36% in June 2023** and **34.06% in March 2023**, coinciding with monsoon logistics friction and financial year-end demand surges.
  - Lowest failure rates observed in October–November (post-audit compliance enforcement).
- **Lead-Time Delay Analysis:**
  - Late shipments suffered an average delay of 8.2 days beyond promised PO delivery date.
  - High-delay shipments resulted in an estimated ₹42 Lakhs in buffer inventory holding costs.

---

## Slide 10: Strategic Recommendations & Action Plan
- **Immediate Interventions (Next 30 Days):**
  - **Issue Formal Cure Notices:** Issue 30-day corrective action plans (CAP) to Tier D suppliers (`SUP012` and `SUP044`).
  - **Dual-Sourcing Activation:** Reallocate 35% of `SUP012`'s electronic purchase volume to `SUP001` (Kaynes Electronics).
- **Medium-Term Strategic Programs (60–90 Days):**
  - **Dynamic SLA Penalties:** Enforce contractual 1.5% liquidated damages per day of unnotified delivery delay.
  - **Incoming Quality Gate (AQL 0.65):** Implement pre-dispatch inspection protocols for all Tier C raw materials suppliers.
- **Long-Term Enterprise Value (6–12 Months):**
  - **Automated Scorecard Governance:** Integrate SQLite/Python scorecard pipeline into live ERP (SAP S/4HANA / Power BI Service) for real-time vendor evaluation.
  - **Projected Impact:** +14% improvement in overall SLA adherence and ₹1.8 Cr savings in defect-related scrap and downtime.

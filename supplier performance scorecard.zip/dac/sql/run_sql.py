#!/usr/bin/env python3
"""
run_sql.py
Phase 2: Executes analysis.sql queries and exports final_scorecard view.
Reads SQLite database at data/supply_chain.db, executes all 8 queries,
creates the supplier_scorecard view, and exports the final view to data/cleaned/final_scorecard.csv.
"""

import os
import sqlite3
import pandas as pd

def get_base_dir():
    """Returns the base project directory."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['sql', 'python', 'data']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DB_PATH = os.path.join(BASE_DIR, 'data', 'supply_chain.db')
SQL_FILE_PATH = os.path.join(BASE_DIR, 'sql', 'analysis.sql')
CLEANED_DIR = os.path.join(BASE_DIR, 'data', 'cleaned')
OUTPUT_CSV_PATH = os.path.join(CLEANED_DIR, 'final_scorecard.csv')

def run_analysis():
    print(f"Connecting to database at {DB_PATH}...")
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"Database file not found at {DB_PATH}. Run setup_db.py first.")

    os.makedirs(CLEANED_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    if not os.path.exists(SQL_FILE_PATH):
        raise FileNotFoundError(f"SQL file not found at {SQL_FILE_PATH}")

    with open(SQL_FILE_PATH, 'r', encoding='utf-8') as f:
        sql_content = f.read()

    # Split script into individual statements
    # We parse out individual query blocks marked by -- QUERY_NAME or separated by semicolons
    print("Executing analysis.sql script...")
    
    # Execute full script to ensure views and all statements are registered
    cursor.executescript(sql_content)
    conn.commit()

    print("\nExecuting Individual Query Demonstrations:")
    print("=" * 80)

    # 1. Q1 Sample: Top 5 On-Time Suppliers
    print("\n--- Q1: TOP 5 ON-TIME SUPPLIERS ---")
    df_q1 = pd.read_sql_query("""
    SELECT s.supplier_name, s.category, COUNT(d.delivery_id) AS total_deliveries,
           ROUND(SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS on_time_pct
    FROM suppliers s
    JOIN purchase_orders po ON s.supplier_id = po.supplier_id
    JOIN deliveries d ON po.po_id = d.po_id
    GROUP BY s.supplier_id, s.supplier_name, s.category
    ORDER BY on_time_pct DESC
    LIMIT 5;
    """, conn)
    print(df_q1.to_string(index=False))

    # 2. Q2 Sample: Top 5 Suppliers by Average Delay Days
    print("\n--- Q2: TOP 5 SUPPLIERS WITH HIGHEST AVERAGE DELAY DAYS ---")
    df_q2 = pd.read_sql_query("""
    SELECT s.supplier_name, s.location, COUNT(d.delivery_id) AS late_deliveries_count,
           ROUND(AVG(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 2) AS avg_delay_days
    FROM suppliers s
    JOIN purchase_orders po ON s.supplier_id = po.supplier_id
    JOIN deliveries d ON po.po_id = d.po_id
    WHERE d.actual_delivery_date > po.expected_delivery_date
    GROUP BY s.supplier_id, s.supplier_name, s.location
    ORDER BY avg_delay_days DESC
    LIMIT 5;
    """, conn)
    print(df_q2.to_string(index=False))

    # 3. Q3 Sample: Top 5 Suppliers by Defect Rate
    print("\n--- Q3: TOP 5 SUPPLIERS WITH HIGHEST DEFECT RATES ---")
    df_q3 = pd.read_sql_query("""
    SELECT s.supplier_name, s.category,
           SUM(d.delivered_qty) AS total_qty,
           COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
           ROUND(COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0), 2) AS defect_rate_pct
    FROM suppliers s
    JOIN purchase_orders po ON s.supplier_id = po.supplier_id
    JOIN deliveries d ON po.po_id = d.po_id
    LEFT JOIN defects df ON d.delivery_id = df.delivery_id
    GROUP BY s.supplier_id, s.supplier_name, s.category
    ORDER BY defect_rate_pct DESC
    LIMIT 5;
    """, conn)
    print(df_q3.to_string(index=False))

    # 4. Q4 Sample: Top 5 Suppliers by Procurement Spend
    print("\n--- Q4: TOP 5 SUPPLIERS BY TOTAL SPEND ---")
    df_q4 = pd.read_sql_query("""
    SELECT s.supplier_name, s.category, COUNT(po.po_id) AS orders,
           ROUND(SUM(po.total_cost), 2) AS total_spend,
           ROUND(AVG(po.total_cost), 2) AS avg_cost
    FROM suppliers s
    JOIN purchase_orders po ON s.supplier_id = po.supplier_id
    GROUP BY s.supplier_id, s.supplier_name, s.category
    ORDER BY total_spend DESC
    LIMIT 5;
    """, conn)
    print(df_q4.to_string(index=False))

    # 5. Q5 Sample: Item Defects
    print("\n--- Q5: MOST DEFECTIVE ITEM TYPES ---")
    df_q5 = pd.read_sql_query("""
    SELECT po.item_name, SUM(d.delivered_qty) AS qty_delivered,
           COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
           ROUND(COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0), 2) AS defect_rate_pct
    FROM purchase_orders po
    JOIN deliveries d ON po.po_id = d.po_id
    LEFT JOIN defects df ON d.delivery_id = df.delivery_id
    GROUP BY po.item_name
    ORDER BY defect_rate_pct DESC
    LIMIT 5;
    """, conn)
    print(df_q5.to_string(index=False))

    # 6. Q6 Sample: Monthly Late Delivery Trend Preview
    print("\n--- Q6: MONTHLY LATE DELIVERY TREND (FIRST 6 MONTHS) ---")
    df_q6 = pd.read_sql_query("""
    SELECT strftime('%Y-%m', d.actual_delivery_date) AS delivery_month,
           COUNT(d.delivery_id) AS deliveries,
           SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_deliveries,
           ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id), 2) AS late_rate_pct
    FROM deliveries d
    JOIN purchase_orders po ON d.po_id = po.po_id
    GROUP BY delivery_month
    ORDER BY delivery_month ASC
    LIMIT 6;
    """, conn)
    print(df_q6.to_string(index=False))

    # 7. Q7 Sample: Top 5 Combined Supplier Ranking
    print("\n--- Q7: TOP 5 PERFORMING SUPPLIERS (OVERALL RANK) ---")
    df_q7 = pd.read_sql_query("""
    SELECT s.supplier_id, s.supplier_name, s.category,
           ROUND(SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id), 2) AS on_time_pct,
           ROUND(COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0), 2) AS defect_rate_pct,
           RANK() OVER (
               ORDER BY 
                   (SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id)) DESC,
                   (COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0)) ASC
           ) AS rank
    FROM suppliers s
    JOIN purchase_orders po ON s.supplier_id = po.supplier_id
    JOIN deliveries d ON po.po_id = d.po_id
    LEFT JOIN defects df ON d.delivery_id = df.delivery_id
    GROUP BY s.supplier_id, s.supplier_name, s.category
    ORDER BY rank ASC
    LIMIT 5;
    """, conn)
    print(df_q7.to_string(index=False))

    # 8. EXPORT FINAL VIEW: supplier_scorecard -> data/cleaned/final_scorecard.csv
    print("\n" + "=" * 80)
    print("EXPORTING FINAL VIEW: supplier_scorecard -> data/cleaned/final_scorecard.csv")
    df_scorecard = pd.read_sql_query("SELECT * FROM supplier_scorecard ORDER BY total_spend DESC;", conn)
    df_scorecard.to_csv(OUTPUT_CSV_PATH, index=False)
    print(f"Successfully exported {len(df_scorecard)} supplier records to {OUTPUT_CSV_PATH}")
    print("\nScorecard Preview (Top 5 rows):")
    print(df_scorecard.head(5).to_string(index=False))

    conn.close()
    return df_scorecard

if __name__ == "__main__":
    run_analysis()

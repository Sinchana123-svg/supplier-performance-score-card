#!/usr/bin/env python3
"""
setup_db.py
Phase 2: Database Setup & Data Ingestion for Sinchana AP Supplier Performance Scorecard
Creates SQLite database at data/supply_chain.db, defines relational schema with integrity constraints,
and loads raw CSV data from data/raw/ into corresponding tables.
"""

import os
import sqlite3
import pandas as pd

def get_base_dir():
    """Returns the base project directory."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['sql', 'python', 'data']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
RAW_DATA_DIR = os.path.join(BASE_DIR, 'data', 'raw')
DB_PATH = os.path.join(BASE_DIR, 'data', 'supply_chain.db')

def setup_database():
    print(f"Connecting to database at {DB_PATH}...")
    
    # Ensure data directory exists
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    # If database file already exists, remove it for clean idempotency
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
            print("Existing database removed for fresh initialization.")
        except Exception as e:
            print(f"Note: Could not remove existing DB ({e}), will re-create tables.")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Enable foreign key support
    cursor.execute("PRAGMA foreign_keys = ON;")

    # 1. Create tables
    print("Creating tables with schema integrity...")

    cursor.executescript("""
    -- Table: suppliers
    DROP TABLE IF EXISTS defects;
    DROP TABLE IF EXISTS deliveries;
    DROP TABLE IF EXISTS purchase_orders;
    DROP TABLE IF EXISTS suppliers;

    CREATE TABLE suppliers (
        supplier_id TEXT PRIMARY KEY,
        supplier_name TEXT NOT NULL,
        location TEXT NOT NULL,
        category TEXT NOT NULL,
        contact_email TEXT NOT NULL
    );

    -- Table: purchase_orders
    CREATE TABLE purchase_orders (
        po_id TEXT PRIMARY KEY,
        supplier_id TEXT NOT NULL,
        order_date TEXT NOT NULL,
        expected_delivery_date TEXT NOT NULL,
        total_cost REAL NOT NULL,
        item_name TEXT NOT NULL,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE CASCADE
    );

    -- Table: deliveries
    CREATE TABLE deliveries (
        delivery_id TEXT PRIMARY KEY,
        po_id TEXT NOT NULL,
        actual_delivery_date TEXT NOT NULL,
        delivered_qty INTEGER NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('On-Time', 'Late')),
        FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id) ON DELETE CASCADE
    );

    -- Table: defects
    CREATE TABLE defects (
        defect_id TEXT PRIMARY KEY,
        delivery_id TEXT NOT NULL,
        defect_qty INTEGER NOT NULL,
        defect_type TEXT NOT NULL,
        FOREIGN KEY (delivery_id) REFERENCES deliveries(delivery_id) ON DELETE CASCADE
    );

    -- Indexes for high-performance analytical queries
    CREATE INDEX idx_po_supplier ON purchase_orders(supplier_id);
    CREATE INDEX idx_po_dates ON purchase_orders(order_date, expected_delivery_date);
    CREATE INDEX idx_deliveries_po ON deliveries(po_id);
    CREATE INDEX idx_deliveries_status ON deliveries(status);
    CREATE INDEX idx_defects_delivery ON defects(delivery_id);
    """)

    # 2. Read and import CSVs
    csv_configs = [
        ('suppliers', 'suppliers.csv'),
        ('purchase_orders', 'purchase_orders.csv'),
        ('deliveries', 'deliveries.csv'),
        ('defects', 'defects.csv')
    ]

    for table_name, csv_file in csv_configs:
        file_path = os.path.join(RAW_DATA_DIR, csv_file)
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Missing required CSV file: {file_path}. Please run generate_data.py first.")
        
        df = pd.read_csv(file_path)
        df.to_sql(table_name, conn, if_exists='append', index=False)
        print(f"Loaded {len(df):>4} records into table '{table_name}' from {csv_file}")

    # 3. Verify counts
    print("\nDatabase verification:")
    for table_name, _ in csv_configs:
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        print(f"  - Table {table_name:<16}: {count:>4} rows")

    conn.commit()
    conn.close()
    print(f"\nDatabase setup completed successfully: {DB_PATH}")

if __name__ == "__main__":
    setup_database()

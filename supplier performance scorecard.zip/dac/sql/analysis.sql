-- ==============================================================================
-- PROJECT: DA-32 Supplier Performance Scorecard for Sinchana AP
-- DOMAIN: Supply Chain & Logistics
-- SCRIPT: analysis.sql
-- PURPOSE: 8 Analytical Queries + Final Scorecard View for Supplier Evaluation
-- COMPATIBILITY: SQLite 3
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- Q1: On-Time Delivery % per Supplier
-- Calculates total deliveries, on-time deliveries, and on-time percentage per supplier.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q1_On_Time_Delivery_Pct
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.category,
    s.location,
    COUNT(d.delivery_id) AS total_deliveries,
    SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) AS on_time_deliveries,
    ROUND(SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS on_time_pct
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
JOIN deliveries d ON po.po_id = d.po_id
GROUP BY s.supplier_id, s.supplier_name, s.category, s.location
ORDER BY on_time_pct DESC;


-- ------------------------------------------------------------------------------
-- Q2: Average Delay Days for Late Deliveries
-- Isolates shipments that breached SLA (actual > expected) and calculates mean delay.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q2_Avg_Delay_Days_Late_Deliveries
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.location,
    COUNT(d.delivery_id) AS late_deliveries_count,
    ROUND(AVG(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 2) AS avg_delay_days,
    ROUND(MAX(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 1) AS max_delay_days,
    ROUND(MIN(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 1) AS min_delay_days
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
JOIN deliveries d ON po.po_id = d.po_id
WHERE d.actual_delivery_date > po.expected_delivery_date
GROUP BY s.supplier_id, s.supplier_name, s.location
ORDER BY avg_delay_days DESC;


-- ------------------------------------------------------------------------------
-- Q3: Defect Rate per Supplier
-- Defect Rate = SUM(defect_qty) / SUM(delivered_qty) * 100 per supplier
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q3_Defect_Rate_Per_Supplier
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.category,
    SUM(d.delivered_qty) AS total_delivered_qty,
    COALESCE(SUM(df.defect_qty), 0) AS total_defective_qty,
    ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate_pct
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
JOIN deliveries d ON po.po_id = d.po_id
LEFT JOIN defects df ON d.delivery_id = df.delivery_id
GROUP BY s.supplier_id, s.supplier_name, s.category
ORDER BY defect_rate_pct DESC;


-- ------------------------------------------------------------------------------
-- Q4: Total Spend and Average Cost per Supplier
-- Evaluates procurement spend exposure and order ticket sizes.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q4_Total_Spend_And_Avg_Cost
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.category,
    s.location,
    COUNT(po.po_id) AS total_orders,
    ROUND(SUM(po.total_cost), 2) AS total_spend,
    ROUND(AVG(po.total_cost), 2) AS avg_order_cost,
    ROUND(MIN(po.total_cost), 2) AS min_order_cost,
    ROUND(MAX(po.total_cost), 2) AS max_order_cost
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
GROUP BY s.supplier_id, s.supplier_name, s.category, s.location
ORDER BY total_spend DESC;


-- ------------------------------------------------------------------------------
-- Q5: Most Defective Item Types
-- Groups by item_name to identify parts with chronic quality and packaging failures.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q5_Most_Defective_Items
SELECT 
    po.item_name,
    COUNT(DISTINCT po.po_id) AS total_po_count,
    SUM(d.delivered_qty) AS total_qty_received,
    COALESCE(SUM(df.defect_qty), 0) AS total_defect_qty,
    ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS item_defect_rate_pct,
    COUNT(df.defect_id) AS defective_shipment_count
FROM purchase_orders po
JOIN deliveries d ON po.po_id = d.po_id
LEFT JOIN defects df ON d.delivery_id = df.delivery_id
GROUP BY po.item_name
ORDER BY item_defect_rate_pct DESC;


-- ------------------------------------------------------------------------------
-- Q6: Monthly Late Delivery Trend
-- Aggregates delivery punctuality across 2023-2024 to track seasonal disruptions.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q6_Monthly_Late_Delivery_Trend
SELECT 
    strftime('%Y-%m', d.actual_delivery_date) AS delivery_month,
    COUNT(d.delivery_id) AS total_deliveries,
    SUM(CASE WHEN d.status = 'On-Time' THEN 1 ELSE 0 END) AS on_time_deliveries,
    SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_deliveries,
    ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id), 2) AS late_delivery_rate_pct,
    ROUND(AVG(CASE WHEN d.status = 'Late' THEN julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date) ELSE 0 END), 2) AS avg_delay_days,
    ROUND(SUM(po.total_cost), 2) AS monthly_spend
FROM deliveries d
JOIN purchase_orders po ON d.po_id = po.po_id
GROUP BY delivery_month
ORDER BY delivery_month ASC;


-- ------------------------------------------------------------------------------
-- Q7: Supplier Ranking - Combine All Core Metrics
-- Ranks suppliers using multi-criteria delivery punctuality and defect minimization.
-- ------------------------------------------------------------------------------
-- QUERY_NAME: Q7_Supplier_Ranking
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.category,
    s.location,
    COUNT(DISTINCT po.po_id) AS order_count,
    ROUND(SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id), 2) AS on_time_pct,
    ROUND(AVG(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 2) AS avg_delay_days,
    ROUND(COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0), 2) AS defect_rate_pct,
    ROUND(SUM(po.total_cost), 2) AS total_spend,
    RANK() OVER (
        ORDER BY 
            (SUM(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id)) DESC,
            (COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0)) ASC
    ) AS supplier_rank
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
JOIN deliveries d ON po.po_id = d.po_id
LEFT JOIN defects df ON d.delivery_id = df.delivery_id
GROUP BY s.supplier_id, s.supplier_name, s.category, s.location
ORDER BY supplier_rank ASC;


-- ------------------------------------------------------------------------------
-- FINAL VIEW: supplier_scorecard
-- Master aggregation consolidating supplier operational KPIs for Power BI & Python.
-- ------------------------------------------------------------------------------
DROP VIEW IF EXISTS supplier_scorecard;

CREATE VIEW supplier_scorecard AS
SELECT 
    s.supplier_id,
    s.supplier_name,
    s.location,
    s.category,
    COUNT(DISTINCT po.po_id) AS total_orders,
    SUM(d.delivered_qty) AS total_qty,
    ROUND(AVG(CASE WHEN d.actual_delivery_date <= po.expected_delivery_date THEN 100.0 ELSE 0 END), 2) AS on_time_pct,
    ROUND(AVG(julianday(d.actual_delivery_date) - julianday(po.expected_delivery_date)), 2) AS avg_delay_days,
    ROUND(COALESCE(SUM(df.defect_qty) * 100.0 / SUM(d.delivered_qty), 0), 2) AS defect_rate_pct,
    ROUND(SUM(po.total_cost), 2) AS total_spend
FROM suppliers s
JOIN purchase_orders po ON s.supplier_id = po.supplier_id
JOIN deliveries d ON po.po_id = d.po_id
LEFT JOIN defects df ON d.delivery_id = df.delivery_id
GROUP BY s.supplier_id, s.supplier_name, s.location, s.category;

# Power BI Dashboard Build Guide: DA-32 Supplier Performance Scorecard
**Client / Domain:** Sinchana AP | Supply Chain & Logistics  
**Data Source:** `powerbi/dashboard_data.xlsx` (Sheets: `Scorecard`, `MonthlyTrend`)  
**Canvas Resolution:** 16:9 Standard (1280 x 720 px)

---

## Architecture Overview
The dashboard comprises 3 executive and operational pages:
- **Page 1: Executive Summary** — High-level enterprise KPIs, supplier tier health donut, spend distribution by geography, and procurement category slicers.
- **Page 2: Supplier Scorecard** — Deep-dive granular supplier matrix with full Red/Yellow/Green conditional formatting, performance data bars, and Top/Bottom comparison bar charts.
- **Page 3: Trends & Operational Analytics** — Monthly late delivery trends across 2023–2024, lead-time delay distributions, and defect root-cause breakdowns.

---

## 15 Step-by-Step Implementation Instructions

### Step 1: Ingest Data into Power BI Desktop
1. Launch **Power BI Desktop**.
2. Click **Get Data** > **Excel Workbook**.
3. Browse to and select `c:\dac\powerbi\dashboard_data.xlsx`.
4. In the Navigator dialog, check both sheets:
   - `Scorecard`
   - `MonthlyTrend`
5. Click **Transform Data** to open Power Query Editor.

---

### Step 2: Validate Data Types and Formats in Power Query
1. In the **Scorecard** query:
   - `supplier_id`, `supplier_name`, `location`, `category`, `rating` &rarr; **Text**
   - `total_orders`, `total_qty` &rarr; **Whole Number**
   - `on_time_pct`, `avg_delay_days`, `defect_rate_pct`, `final_score` &rarr; **Decimal Number**
   - `total_spend` &rarr; **Fixed Decimal Number (Currency)**
2. In the **MonthlyTrend** query:
   - `delivery_month` &rarr; **Text** (or Date formatted as `YYYY-MM`)
   - `total_orders`, `total_deliveries`, `on_time_deliveries`, `late_deliveries`, `defect_incident_count`, `total_defective_qty` &rarr; **Whole Number**
   - `late_delivery_pct`, `avg_delay_days`, `defect_rate_pct` &rarr; **Decimal Number**
   - `monthly_spend` &rarr; **Fixed Decimal Number (Currency)**
3. Click **Close & Apply**.

---

### Step 3: Establish a Dedicated DAX Measures Table
1. On the **Home** tab, click **Enter Data**.
2. Name the table `_Measures` and click **Load**.
3. Create all measures inside this container for clean governance.
4. Delete the default blank `Column1` after creating the first measure.

---

### Step 4: Create Core DAX Measures
Navigate to the `_Measures` table, right-click, select **New Measure**, and paste each formula from `powerbi/DAX_Measures.txt`:

```dax
Total Spend = SUM(Scorecard[total_spend])

OnTime% = AVERAGE(Scorecard[on_time_pct])

Defect% = AVERAGE(Scorecard[defect_rate_pct])

Avg Delay Days = AVERAGE(Scorecard[avg_delay_days])

Average Final Score = AVERAGE(Scorecard[final_score])

Total Suppliers = DISTINCTCOUNT(Scorecard[supplier_id])

Rating Color = 
SWITCH(
    SELECTEDVALUE(Scorecard[rating]),
    "A", "#2E7D32",
    "B", "#1565C0",
    "C", "#F57C00",
    "D", "#D32F2F",
    "#757575"
)
```

Set Formatting:
- `Total Spend`: Currency &rarr; `₹` English (India) or `$`, 0 decimals
- `OnTime%` & `Defect%`: Percentage &rarr; 2 decimal places
- `Avg Delay Days`: Decimal &rarr; 2 decimal places
- `Average Final Score`: Decimal &rarr; 2 decimal places

---

### Step 5: Global Canvas Theme & Background Setup
1. In the **View** tab &rarr; **Themes** &rarr; select **Executive** or **Innovate**.
2. Canvas Background: `#F8F9FA` with **0% Transparency**.
3. Add a Top Header Banner shape across all pages:
   - **Type:** Rectangle (`X: 0, Y: 0, Width: 1280, Height: 70`)
   - **Fill:** Deep Navy Blue (`#0F172A`)
   - **Title Text:** `SINCHANA AP — SUPPLIER PERFORMANCE SCORECARD` (Font: Segoe UI, Bold, 20pt, White `#FFFFFF`)
   - **Subtitle Text:** `Procurement Operations & Quality Risk Management` (10pt, Light Slate `#94A3B8`)

---

### Step 6: Page 1 — Configure 4 Executive KPI Cards
Create 4 Card (New) or Standard Card visuals across the top row:

1. **Card 1: Total Procurement Spend**
   - **Field:** `[Total Spend]`
   - **Callout Value:** Bold, 28pt, Color: `#0F172A`
   - **Category Label:** "Total Spend (FY 23-24)"
   - **Position:** `X: 30, Y: 90, Width: 280, Height: 110`
   - **Border:** Card shadow enabled, 8px border radius.

2. **Card 2: Average On-Time Delivery %**
   - **Field:** `[OnTime%]`
   - **Callout Value:** Bold, 28pt, Color: `#1E88E5`
   - **Category Label:** "On-Time Delivery Rate (SLA Target: 85%)"
   - **Position:** `X: 330, Y: 90, Width: 280, Height: 110`

3. **Card 3: Average Defect Rate %**
   - **Field:** `[Defect%]`
   - **Callout Value:** Bold, 28pt, Color: `#E53935`
   - **Category Label:** "Defect Rate (Quality Cap: 1.5%)"
   - **Position:** `X: 630, Y: 90, Width: 280, Height: 110`

4. **Card 4: Total Active Suppliers**
   - **Field:** `[Total Suppliers]`
   - **Callout Value:** Bold, 28pt, Color: `#0F172A`
   - **Category Label:** "Active Audited Suppliers"
   - **Position:** `X: 930, Y: 90, Width: 320, Height: 110`

---

### Step 7: Page 1 — Build Rating Tier Donut Chart
1. **Visual Type:** Donut Chart
2. **Legend:** `Scorecard[rating]`
3. **Values:** `[Total Suppliers]`
4. **Colors (Data Colors):**
   - Tier A: Forest Green (`#2E7D32`)
   - Tier B: Royal Blue (`#1565C0`)
   - Tier C: Amber Orange (`#F57C00`)
   - Tier D: Crimson Red (`#D32F2F`)
5. **Title:** "Supplier Rating Distribution (Tier A to D)"
6. **Position:** `X: 30, Y: 220, Width: 460, Height: 350`

---

### Step 8: Page 1 — Build Spend by Location Donut & Filter Slicers
1. **Visual Type:** Donut Chart
   - **Legend:** `Scorecard[location]` (Bangalore, Mumbai, Delhi, Chennai, Pune)
   - **Values:** `[Total Spend]`
   - **Title:** "Procurement Spend by Supplier Geography"
   - **Position:** `X: 510, Y: 220, Width: 460, Height: 350`
2. **Slicers:**
   - **Category Slicer (Tile / Chiclet):** `Scorecard[category]` &rarr; `X: 990, Y: 220, Width: 260, Height: 170`
   - **Location Slicer (Dropdown):** `Scorecard[location]` &rarr; `X: 990, Y: 400, Width: 260, Height: 170`

---

### Step 9: Page 2 — Construct Supplier Scorecard Master Table
1. Rename Page 2 to: `Supplier Scorecard`.
2. Add Header Banner matching Step 5.
3. **Visual Type:** Table
4. Add columns in order:
   - `Scorecard[supplier_id]` (Supplier ID)
   - `Scorecard[supplier_name]` (Supplier Name)
   - `Scorecard[location]` (Location)
   - `Scorecard[category]` (Category)
   - `Scorecard[total_orders]` (Total POs)
   - `Scorecard[on_time_pct]` (On-Time %)
   - `Scorecard[avg_delay_days]` (Avg Delay Days)
   - `Scorecard[defect_rate_pct]` (Defect Rate %)
   - `Scorecard[total_spend]` (Total Spend)
   - `Scorecard[final_score]` (Final Score)
   - `Scorecard[rating]` (Rating)
5. **Position:** `X: 30, Y: 90, Width: 1220, Height: 380`

---

### Step 10: Page 2 — Apply Red/Yellow/Green Conditional Formatting
1. In Table Visual &rarr; **Format Visual** &rarr; **Cell elements**:
2. **On-Time Delivery % Background:**
   - Select `on_time_pct` &rarr; Background color `fx` &rarr; Format Style: **Rules**.
   - `Scorecard[on_time_pct]`:
     - `>= 85%` &rarr; `#E8F5E9` (Soft Green)
     - `>= 70% and < 85%` &rarr; `#FFF8E1` (Soft Amber)
     - `< 70%` &rarr; `#FFEBEE` (Soft Crimson)
3. **Defect Rate % Background:**
   - Select `defect_rate_pct` &rarr; Background color `fx` &rarr; Format Style: **Rules**.
   - `Scorecard[defect_rate_pct]`:
     - `<= 1.0%` &rarr; `#E8F5E9` (Soft Green)
     - `> 1.0% and <= 2.0%` &rarr; `#FFF8E1` (Soft Amber)
     - `> 2.0%` &rarr; `#FFEBEE` (Soft Crimson)
4. **Final Score Data Bars:**
   - Select `final_score` &rarr; Data bars `fx`.
   - Minimum: `0`, Maximum: `100`.
   - Bar color: Deep Blue (`#1565C0`).
5. **Rating Tier Font Color:**
   - Select `rating` &rarr; Font color `fx` &rarr; Format Style: **Field Value**.
   - Based on field: `_Measures[Rating Color]`.

---

### Step 11: Page 2 — Build Top & Bottom Bar Charts
Place two comparative charts below the master scorecard table:
1. **Left Visual:** Clustered Bar Chart (Top 10 On-Time Suppliers)
   - **Y-Axis:** `Scorecard[supplier_name]` (Top 10 filter by `on_time_pct`)
   - **X-Axis:** `Scorecard[on_time_pct]`
   - **Bar Color:** `#2E7D32`
   - **Position:** `X: 30, Y: 490, Width: 590, Height: 210`
2. **Right Visual:** Clustered Bar Chart (Worst 10 Defect Suppliers)
   - **Y-Axis:** `Scorecard[supplier_name]` (Top 10 filter by `defect_rate_pct` descending)
   - **X-Axis:** `Scorecard[defect_rate_pct]`
   - **Bar Color:** `#D32F2F`
   - **Position:** `X: 650, Y: 490, Width: 600, Height: 210`

---

### Step 12: Page 3 — Trends & Operational Root Cause Analysis
1. Rename Page 3 to: `Trends & Operations`.
2. Add Header Banner.
3. **Visual 1: Line and Clustered Column Chart (Monthly Late Trend)**
   - **X-Axis:** `MonthlyTrend[delivery_month]`
   - **Column Y-Axis:** `MonthlyTrend[late_deliveries]` (Bar color: `#90CAF9`)
   - **Line Y-Axis:** `MonthlyTrend[late_delivery_pct]` (Line color: `#D32F2F`, stroke width: 3, markers enabled)
   - **Title:** "Monthly Late Delivery Count & Failure Rate % (2023–2024)"
   - **Position:** `X: 30, Y: 90, Width: 780, Height: 330`

---

### Step 13: Page 3 — Category Delay Bar Chart & Financial Impact
1. **Visual 2: Clustered Column Chart (Average Delay Days by Category)**
   - **X-Axis:** `Scorecard[category]`
   - **Y-Axis:** `[Avg Delay Days]`
   - **Data Color:** `#FB8C00`
   - **Title:** "Lead Time SLA Delay Days by Procurement Category"
   - **Position:** `X: 830, Y: 90, Width: 420, Height: 330`
2. **Visual 3: Area Chart / Monthly Spend vs. Late Rate**
   - **X-Axis:** `MonthlyTrend[delivery_month]`
   - **Y-Axis:** `MonthlyTrend[monthly_spend]`
   - **Title:** "Procurement Capital Outflow vs. Delivery Timeliness"
   - **Position:** `X: 30, Y: 440, Width: 1220, Height: 250`

---

### Step 14: Configure Tooltips, Interactivity & Cross-Filtering
1. Enable **Cross-filtering** between Page 1 Donut charts and KPI cards.
2. In the Scorecard Table (Page 2), configure modern tooltips showing:
   - Supplier Contact Email
   - Delivered Quantity
   - Highest Defect Type
3. Enable column sorting on `final_score` (Descending by default).

---

### Step 15: Exact Canvas Coordinate Layout Reference Grid

| Page | Visual Element | Visual Type | X | Y | Width | Height |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **P1** | Header Banner | Shape / Text | 0 | 0 | 1280 | 70 |
| **P1** | KPI Card: Total Spend | Card | 30 | 90 | 280 | 110 |
| **P1** | KPI Card: On-Time % | Card | 330 | 90 | 280 | 110 |
| **P1** | KPI Card: Defect % | Card | 630 | 90 | 280 | 110 |
| **P1** | KPI Card: Suppliers | Card | 930 | 90 | 320 | 110 |
| **P1** | Rating Health Donut | Donut Chart | 30 | 220 | 460 | 350 |
| **P1** | Spend Geography Donut| Donut Chart | 510 | 220 | 460 | 350 |
| **P1** | Category Slicer | Tile Slicer | 990 | 220 | 260 | 170 |
| **P1** | Location Slicer | Dropdown | 990 | 400 | 260 | 170 |
| **P2** | Scorecard Matrix | Table | 30 | 90 | 1220 | 380 |
| **P2** | Top 10 On-Time Bars | Bar Chart | 30 | 490 | 590 | 210 |
| **P2** | Worst 10 Defect Bars| Bar Chart | 650 | 490 | 600 | 210 |
| **P3** | Monthly Trend Combo | Line & Column | 30 | 90 | 780 | 330 |
| **P3** | Category Delay Bars | Column Chart | 830 | 90 | 420 | 330 |
| **P3** | Monthly Spend Trend | Area Chart | 30 | 440 | 1220 | 250 |

---
**Verification Checklist:**
- [x] Excel data source connects without schema drift.
- [x] All 50 suppliers and 25 monthly trend rows appear.
- [x] Conditional formatting displays green/amber/crimson bands accurately.
- [x] Measures recalculate dynamically upon category or location slicer selection.

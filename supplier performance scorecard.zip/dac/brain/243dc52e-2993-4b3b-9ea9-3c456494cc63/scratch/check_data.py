import sqlite3
conn = sqlite3.connect('C:/dac/data/supply_chain.db')
cur = conn.cursor()

grades = cur.execute('SELECT rating, COUNT(*) FROM suppliers GROUP BY rating ORDER BY rating').fetchall()
print('Grade distribution:', grades)

top5 = cur.execute("""
  SELECT s.id, s.name, s.category, s.location, s.rating,
    COUNT(po.id) as orders,
    ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) as ontime_rate,
    ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) as defect_rate,
    ROUND(SUM(po.cost)/100000,1) as spend_lakhs
  FROM suppliers s
  JOIN purchase_orders po ON s.id=po.supplier_id
  JOIN deliveries d ON po.id=d.order_id
  LEFT JOIN (SELECT delivery_id, SUM(defect_qty) as defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
  WHERE s.rating='A'
  GROUP BY s.id ORDER BY ontime_rate DESC LIMIT 5
""").fetchall()
print('Top 5 Grade A:', top5)

loc = cur.execute("""
  SELECT s.location,
    COUNT(DISTINCT s.id) as suppliers,
    ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) as ontime_rate,
    ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) as defect_rate
  FROM suppliers s
  JOIN purchase_orders po ON s.id=po.supplier_id
  JOIN deliveries d ON po.id=d.order_id
  LEFT JOIN (SELECT delivery_id, SUM(defect_qty) as defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
  GROUP BY s.location ORDER BY ontime_rate DESC
""").fetchall()
print('By location:', loc)

bottom = cur.execute("""
  SELECT s.id, s.name, s.category, s.rating,
    ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) as ontime_rate,
    ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) as defect_rate,
    ROUND(SUM(po.cost)/100000,1) as spend_lakhs
  FROM suppliers s
  JOIN purchase_orders po ON s.id=po.supplier_id
  JOIN deliveries d ON po.id=d.order_id
  LEFT JOIN (SELECT delivery_id, SUM(defect_qty) as defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
  WHERE s.rating IN ('C','D')
  GROUP BY s.id ORDER BY ontime_rate ASC LIMIT 8
""").fetchall()
print('Bottom performers:', bottom)

global_kpi = cur.execute("""
  SELECT 
    COUNT(DISTINCT s.id) as suppliers,
    COUNT(po.id) as total_orders,
    ROUND(SUM(po.cost)/10000000,2) as spend_crore,
    ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),2) as ontime,
    ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) as defect_rate,
    ROUND(AVG(julianday(po.expected_date)-julianday(po.order_date)),1) as avg_lead
  FROM suppliers s
  JOIN purchase_orders po ON s.id=po.supplier_id
  JOIN deliveries d ON po.id=d.order_id
  LEFT JOIN (SELECT delivery_id, SUM(defect_qty) as defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
""").fetchone()
print('Global KPI:', global_kpi)

conn.close()

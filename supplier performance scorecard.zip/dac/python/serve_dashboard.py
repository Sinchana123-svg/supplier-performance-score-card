#!/usr/bin/env python3
"""
python/serve_dashboard.py
DA-32: Local Dashboard HTTP Server
Hosts the Supplier Performance Scorecard dashboard at http://localhost:8080/dashboard.html
No XAMPP, No external web server required. Pure native Python standard library.
"""

import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DASHBOARD_DIR = os.path.join(BASE_DIR, 'dashboard')

class DashboardRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DASHBOARD_DIR, **kwargs)

    def do_GET(self):
        # Normalize routing so localhost:8080/, /dashboard.html, and /dashboard/dashboard.html all work
        if self.path in ['/', '/dashboard', '/dashboard/']:
            self.path = '/dashboard.html'
        elif self.path.startswith('/dashboard/'):
            self.path = self.path.replace('/dashboard/', '/', 1)
        return super().do_GET()

    def log_message(self, format, *args):
        # Clean logging
        sys.stdout.write(f"[HTTP 8080] {self.address_string()} - {format % args}\n")
        sys.stdout.flush()

def run_server(port=8080):
    server_address = ('', port)
    httpd = ThreadingHTTPServer(server_address, DashboardRequestHandler)
    print("=" * 80)
    print(f"DA-32 SUPPLIER PERFORMANCE SCORECARD DASHBOARD SERVER")
    print(f"Serving from: {DASHBOARD_DIR}")
    print(f"Access URL  : http://localhost:{port}/dashboard.html")
    print(f"Alternative : http://127.0.0.1:{port}/dashboard.html")
    print("=" * 80)
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping dashboard server...")
        httpd.server_close()

if __name__ == '__main__':
    port = 8080
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port)

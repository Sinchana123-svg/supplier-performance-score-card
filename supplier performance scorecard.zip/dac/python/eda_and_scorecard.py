#!/usr/bin/env python3
"""
eda_and_scorecard.py
Phase 3: Exploratory Data Analysis, Weighted Scoring Engine & Visualization Suite
Calculates weighted composite score and letter ratings (A/B/C/D), exports final scorecard with ratings,
generates 6 high-resolution charts in images/, and displays executive top 3 / bottom 3 suppliers.
"""

import os
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set visual aesthetics
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica', 'sans-serif']
plt.rcParams['axes.edgecolor'] = '#CCCCCC'
plt.rcParams['axes.linewidth'] = 0.8

def get_base_dir():
    """Returns the base project directory."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
CLEANED_DIR = os.path.join(BASE_DIR, 'data', 'cleaned')
IMAGES_DIR = os.path.join(BASE_DIR, 'images')
DB_PATH = os.path.join(BASE_DIR, 'data', 'supply_chain.db')
SCORECARD_IN_CSV = os.path.join(CLEANED_DIR, 'final_scorecard.csv')
SCORECARD_OUT_CSV = os.path.join(CLEANED_DIR, 'final_scorecard_with_rating.csv')

os.makedirs(CLEANED_DIR, exist_ok=True)
os.makedirs(IMAGES_DIR, exist_ok=True)

def calculate_scorecard():
    print("=" * 80)
    print("PHASE 3: EDA & WEIGHTED SUPPLIER SCORECARD ENGINE")
    print("=" * 80)

    # 1. Load final_scorecard.csv
    print(f"\n1. Loading scorecard data from {SCORECARD_IN_CSV}...")
    if not os.path.exists(SCORECARD_IN_CSV):
        raise FileNotFoundError(f"Missing {SCORECARD_IN_CSV}. Please run run_sql.py first.")

    df = pd.read_csv(SCORECARD_IN_CSV)
    print(f"Loaded {len(df)} supplier records.")

    # 2. Calculate Weighted Score:
    # final_score = (on_time_pct * 0.50) + ((100 - defect_rate_pct*10) * 0.30) + (20) - penalize for high avg_delay.
    # Normalize to 0-100.
    print("\n2. Computing multi-criteria weighted performance scores...")
    
    # 50% Weight: On-Time Delivery %
    on_time_component = df['on_time_pct'] * 0.50

    # 30% Weight: Defect Quality Score (100 - defect_rate * 10, floored at 0)
    quality_score_raw = np.maximum(0, 100.0 - (df['defect_rate_pct'] * 10.0))
    quality_component = quality_score_raw * 0.30

    # 20% Base: Timeliness & Delay Penalty
    # Positive avg_delay_days represents delivery delays. Penalize 6.0 points per day of positive average delay.
    delay_penalty = np.maximum(0, df['avg_delay_days']) * 6.0
    timeliness_component = np.maximum(0, 20.0 - delay_penalty)

    # Raw Composite Score
    composite_score = on_time_component + quality_component + timeliness_component

    # Normalize to 0-100 range and round to 2 decimals
    df['final_score'] = np.clip(composite_score, 0.0, 100.0).round(2)

    # 3. Create Rating column:
    # A: score >= 90
    # B: score >= 75 and < 90
    # C: score >= 60 and < 75
    # D: score < 60
    conditions = [
        (df['final_score'] >= 90.0),
        (df['final_score'] >= 75.0) & (df['final_score'] < 90.0),
        (df['final_score'] >= 60.0) & (df['final_score'] < 75.0),
        (df['final_score'] < 60.0)
    ]
    choices = ['A', 'B', 'C', 'D']
    df['rating'] = np.select(conditions, choices, default='D')

    # Save to final_scorecard_with_rating.csv
    df.to_csv(SCORECARD_OUT_CSV, index=False)
    print(f"Saved scored and rated supplier dataset to: {SCORECARD_OUT_CSV}")

    # Summary by Rating
    rating_counts = df['rating'].value_counts().reindex(['A', 'B', 'C', 'D'], fill_value=0)
    print("\nSupplier Rating Distribution:")
    for tier, count in rating_counts.items():
        pct = (count / len(df)) * 100
        print(f"  Tier {tier}: {count:>2} suppliers ({pct:>5.1f}%)")

    # 4. Generate 6 Visualizations
    print("\n3. Generating 6 executive charts in images/ folder...")
    generate_visualizations(df)

    # 5. Display Best and Worst Suppliers
    print("\n" + "=" * 80)
    print("EXECUTIVE SCORECARD HIGHLIGHTS")
    print("=" * 80)

    # Sort by final_score descending
    df_sorted = df.sort_values(by='final_score', ascending=False).reset_index(drop=True)

    print("\nTOP 3 BEST SUPPLIERS (STRATEGIC PARTNERS):")
    top_3 = df_sorted.head(3)
    for rank, (_, row) in enumerate(top_3.iterrows(), start=1):
        print(f"  {rank}. [{row['supplier_id']}] {row['supplier_name']} ({row['category']} - {row['location']})")
        print(f"     Score: {row['final_score']:.2f} | Rating: {row['rating']} | On-Time: {row['on_time_pct']:.2f}% | Defect Rate: {row['defect_rate_pct']:.2f}% | Spend: INR {row['total_spend']:,.2f}")

    print("\nTOP 3 WORST SUPPLIERS (HIGH RISK - ACTION REQUIRED):")
    worst_3 = df_sorted.tail(3).iloc[::-1]
    for rank, (_, row) in enumerate(worst_3.iterrows(), start=1):
        print(f"  {rank}. [{row['supplier_id']}] {row['supplier_name']} ({row['category']} - {row['location']})")
        print(f"     Score: {row['final_score']:.2f} | Rating: {row['rating']} | On-Time: {row['on_time_pct']:.2f}% | Defect Rate: {row['defect_rate_pct']:.2f}% | Spend: INR {row['total_spend']:,.2f}")

    print("=" * 80)
    return df

def generate_visualizations(df):
    """Generates and saves the 6 requested project charts."""
    palette_ratings = {'A': '#2E7D32', 'B': '#1565C0', 'C': '#F57C00', 'D': '#D32F2F'}

    # -------------------------------------------------------------
    # 1. on_time_barchart.png (Top 15 suppliers by on-time %)
    # -------------------------------------------------------------
    top15_ontime = df.sort_values(by='on_time_pct', ascending=True).tail(15)
    plt.figure(figsize=(10, 7), dpi=300)
    bars = plt.barh(top15_ontime['supplier_name'], top15_ontime['on_time_pct'], color='#1E88E5', edgecolor='#0D47A1', height=0.65)
    plt.axvline(x=85.0, color='#2E7D32', linestyle='--', linewidth=1.5, label='Target Benchmark (85%)')
    plt.xlabel('On-Time Delivery Rate (%)', fontsize=11, fontweight='bold', labelpad=10)
    plt.title('Top 15 Suppliers by On-Time Delivery Performance (SLA Compliance)', fontsize=13, fontweight='bold', pad=15)
    plt.xlim(0, 100)
    
    for bar in bars:
        width = bar.get_width()
        plt.text(width + 1.0, bar.get_y() + bar.get_height()/2, f"{width:.1f}%",
                 ha='left', va='center', fontsize=9, fontweight='bold', color='#1A237E')

    plt.legend(loc='lower right', frameon=True)
    plt.tight_layout()
    img1_path = os.path.join(IMAGES_DIR, 'on_time_barchart.png')
    plt.savefig(img1_path)
    plt.close()
    print(f"  [1/6] Saved: {img1_path}")

    # -------------------------------------------------------------
    # 2. defect_rate_barchart.png (Worst 15 suppliers by defect rate)
    # -------------------------------------------------------------
    worst15_defects = df.sort_values(by='defect_rate_pct', ascending=True).tail(15)
    plt.figure(figsize=(10, 7), dpi=300)
    bars = plt.barh(worst15_defects['supplier_name'], worst15_defects['defect_rate_pct'], color='#E53935', edgecolor='#B71C1C', height=0.65)
    plt.axvline(x=1.5, color='#F57C00', linestyle='--', linewidth=1.5, label='Tolerance Limit (1.5%)')
    plt.xlabel('Defect Rate (%)', fontsize=11, fontweight='bold', labelpad=10)
    plt.title('Worst 15 Suppliers by Defect Rate (Quality Risk Analysis)', fontsize=13, fontweight='bold', pad=15)
    plt.xlim(0, max(worst15_defects['defect_rate_pct']) * 1.25)

    for bar in bars:
        width = bar.get_width()
        plt.text(width + 0.05, bar.get_y() + bar.get_height()/2, f"{width:.2f}%",
                 ha='left', va='center', fontsize=9, fontweight='bold', color='#B71C1C')

    plt.legend(loc='lower right', frameon=True)
    plt.tight_layout()
    img2_path = os.path.join(IMAGES_DIR, 'defect_rate_barchart.png')
    plt.savefig(img2_path)
    plt.close()
    print(f"  [2/6] Saved: {img2_path}")

    # -------------------------------------------------------------
    # 3. spend_piechart.png (Spend by category)
    # -------------------------------------------------------------
    spend_by_cat = df.groupby('category')['total_spend'].sum().reset_index()
    spend_by_cat['spend_crores'] = spend_by_cat['total_spend'] / 1e7
    cat_colors = ['#1E88E5', '#43A047', '#FB8C00', '#8E24AA']
    
    plt.figure(figsize=(8, 7), dpi=300)
    wedges, texts, autotexts = plt.pie(
        spend_by_cat['total_spend'],
        labels=spend_by_cat['category'],
        autopct='%1.1f%%',
        startangle=140,
        colors=cat_colors,
        explode=(0.04, 0.04, 0.04, 0.04),
        wedgeprops=dict(width=0.6, edgecolor='white', linewidth=2)
    )
    for at in autotexts:
        at.set_color('white')
        at.set_weight('bold')
        at.set_fontsize(11)

    total_procurement_cr = spend_by_cat['spend_crores'].sum()
    plt.title(f'Total Procurement Spend by Category\n(Total: INR {total_procurement_cr:.2f} Cr)', fontsize=13, fontweight='bold', pad=15)
    plt.tight_layout()
    img3_path = os.path.join(IMAGES_DIR, 'spend_piechart.png')
    plt.savefig(img3_path)
    plt.close()
    print(f"  [3/6] Saved: {img3_path}")

    # -------------------------------------------------------------
    # 4. monthly_trend_line.png (Late deliveries by month)
    # -------------------------------------------------------------
    conn = sqlite3.connect(DB_PATH)
    df_monthly = pd.read_sql_query("""
    SELECT strftime('%Y-%m', d.actual_delivery_date) AS delivery_month,
           COUNT(d.delivery_id) AS total_deliveries,
           SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_deliveries,
           ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(d.delivery_id), 2) AS late_rate_pct
    FROM deliveries d
    JOIN purchase_orders po ON d.po_id = po.po_id
    GROUP BY delivery_month
    ORDER BY delivery_month ASC;
    """, conn)
    conn.close()

    fig, ax1 = plt.subplots(figsize=(11, 6), dpi=300)
    ax2 = ax1.twinx()

    x_indices = list(range(len(df_monthly['delivery_month'])))
    ax1.bar(x_indices, df_monthly['late_deliveries'], color='#90CAF9', alpha=0.75, width=0.55, label='Late Deliveries (Volume)')
    ax2.plot(x_indices, df_monthly['late_rate_pct'], color='#D32F2F', linewidth=2.5, marker='o', label='Late Rate %')

    ax1.set_xlabel('Delivery Month', fontsize=11, fontweight='bold', labelpad=10)
    ax1.set_ylabel('Late Delivery Count (Shipments)', fontsize=11, fontweight='bold', color='#1565C0')
    ax2.set_ylabel('Late Delivery Rate (%)', fontsize=11, fontweight='bold', color='#D32F2F')
    
    ax1.set_xticks(x_indices)
    ax1.set_xticklabels(df_monthly['delivery_month'], rotation=45, ha='right', fontsize=9)
    ax2.set_ylim(0, max(df_monthly['late_rate_pct']) * 1.35)
    ax2.axhline(y=30.0, color='#FF9800', linestyle=':', label='Target SLA Cap (30%)')

    plt.title('Monthly Late Delivery Trend & Failure Rate (2023 - 2024)', fontsize=13, fontweight='bold', pad=15)
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', frameon=True)

    plt.tight_layout()
    img4_path = os.path.join(IMAGES_DIR, 'monthly_trend_line.png')
    plt.savefig(img4_path)
    plt.close()
    print(f"  [4/6] Saved: {img4_path}")

    # -------------------------------------------------------------
    # 5. scatter_spend_vs_quality.png
    # -------------------------------------------------------------
    plt.figure(figsize=(10, 7), dpi=300)
    for rating_code in ['A', 'B', 'C', 'D']:
        subset = df[df['rating'] == rating_code]
        if not subset.empty:
            plt.scatter(
                subset['total_spend'] / 1e5,
                subset['defect_rate_pct'],
                s=subset['total_orders'] * 2.5,
                c=palette_ratings[rating_code],
                alpha=0.8,
                edgecolors='black',
                linewidths=0.7,
                label=f'Rating {rating_code} ({len(subset)})'
            )

    plt.axhline(y=1.5, color='gray', linestyle='--', linewidth=1, alpha=0.7)
    plt.axvline(x=(df['total_spend'] / 1e5).median(), color='gray', linestyle='--', linewidth=1, alpha=0.7)

    # Highlight notorious supplier SUP012
    sup12 = df[df['supplier_id'] == 'SUP012']
    if not sup12.empty:
        r = sup12.iloc[0]
        plt.annotate(
            f"SUP012 (Worst Performer)\nDefect: {r['defect_rate_pct']:.2f}% | Score: {r['final_score']:.1f}",
            xy=(r['total_spend'] / 1e5, r['defect_rate_pct']),
            xytext=(r['total_spend'] / 1e5 + 5, r['defect_rate_pct'] + 0.35),
            arrowprops=dict(facecolor='black', arrowstyle='->', lw=1.5),
            fontsize=9, fontweight='bold', bbox=dict(boxstyle="round,pad=0.3", fc="#FFCDD2", ec="#D32F2F", lw=1)
        )

    plt.xlabel('Total Procurement Spend (INR Lakhs)', fontsize=11, fontweight='bold', labelpad=10)
    plt.ylabel('Defect Rate (%)', fontsize=11, fontweight='bold', labelpad=10)
    plt.title('Supplier Risk Matrix: Total Spend vs. Defect Rate\n(Bubble size = Total Order Volume)', fontsize=13, fontweight='bold', pad=15)
    plt.legend(title='Supplier Tier', loc='upper right', frameon=True)
    plt.tight_layout()
    img5_path = os.path.join(IMAGES_DIR, 'scatter_spend_vs_quality.png')
    plt.savefig(img5_path)
    plt.close()
    print(f"  [5/6] Saved: {img5_path}")

    # -------------------------------------------------------------
    # 6. rating_donut.png (Count of A,B,C,D suppliers)
    # -------------------------------------------------------------
    rating_summary = df['rating'].value_counts().reindex(['A', 'B', 'C', 'D'], fill_value=0)
    colors = [palette_ratings[k] for k in rating_summary.index]
    
    plt.figure(figsize=(7, 7), dpi=300)
    wedges, texts, autotexts = plt.pie(
        rating_summary.values,
        labels=[f"Rating {k}\n({v} Suppliers)" for k, v in rating_summary.items()],
        autopct='%1.1f%%',
        startangle=90,
        colors=colors,
        wedgeprops=dict(width=0.45, edgecolor='white', linewidth=2),
        pctdistance=0.75
    )
    for at in autotexts:
        at.set_color('white')
        at.set_weight('bold')
        at.set_fontsize(11)

    plt.title('Supplier Rating Tier Distribution\n(Weighted Score Classification: A >= 90, B >= 75, C >= 60, D < 60)', fontsize=12, fontweight='bold', pad=15)
    plt.tight_layout()
    img6_path = os.path.join(IMAGES_DIR, 'rating_donut.png')
    plt.savefig(img6_path)
    plt.close()
    print(f"  [6/6] Saved: {img6_path}")

if __name__ == "__main__":
    calculate_scorecard()

#!/usr/bin/env python3
"""
python/scorecard_logic.py
DA-32: Supplier Performance Scorecard Logic & Grading Engine
Stack: SQL (SQLite) + Python + Power BI

Logic:
- OnTimeRate = OnTime / Total * 100
- DefectRate = DefectQty / DeliveredQty * 100
- QualityScore = max(0, 100 - (DefectRate * 10))
- FinalScore = (OnTimeRate * 0.60) + (QualityScore * 0.40)
- Grade A >= 90, B >= 75, C >= 60, D < 60

Outputs:
1. C:\\dac\\data\\cleaned\\final_scorecard_with_rating.csv (50 rows)
2. C:\\dac\\powerbi\\dashboard_data.xlsx (3 sheets: Supplier_Scorecard, Purchase_Orders, Monthly_Category_Summary)
3. Updates rating in SQLite (supply_chain.db)
"""

import os
import sqlite3
import pandas as pd
import numpy as np

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DATA_DIR = os.path.join(BASE_DIR, 'data')
CLEANED_DIR = os.path.join(DATA_DIR, 'cleaned')
POWERBI_DIR = os.path.join(BASE_DIR, 'powerbi')
DB_PATH = os.path.join(DATA_DIR, 'supply_chain.db')

os.makedirs(CLEANED_DIR, exist_ok=True)
os.makedirs(POWERBI_DIR, exist_ok=True)

def compute_scorecard():
    print("=" * 80)
    print("DA-32: SUPPLIER PERFORMANCE SCORECARD COMPUTATION")
    print(f"Connecting to database: {DB_PATH}")
    print("=" * 80)

    conn = sqlite3.connect(DB_PATH)

    # 1. Query raw performance metrics per supplier
    query = """
    SELECT 
        s.id AS supplier_id,
        s.name AS supplier_name,
        s.category,
        s.location,
        COUNT(po.id) AS total_orders,
        SUM(po.qty) AS total_qty,
        SUM(po.cost) AS total_spend,
        AVG(julianday(po.expected_date) - julianday(po.order_date)) AS avg_lead_time_days,
        SUM(d.delivered_qty) AS delivered_qty,
        SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        COALESCE(SUM(df.defect_qty), 0) AS defect_qty
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty
        FROM defects
        GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY s.id, s.name, s.category, s.location
    ORDER BY s.id;
    """

    df = pd.read_sql_query(query, conn)
    print(f"Loaded aggregated data for {len(df)} suppliers.")

    # 2. Scorecard Metric Calculations
    # OnTimeRate = OnTime / Total * 100
    df['on_time_rate'] = ((df['on_time_orders'] / df['total_orders']) * 100.0).round(2)

    # DefectRate = DefectQty / DeliveredQty * 100
    df['defect_rate'] = ((df['defect_qty'] / df['delivered_qty']) * 100.0).round(2)

    # Quality Score: 100 - (DefectRate * 10), clamped between 0 and 100
    df['quality_score'] = np.clip(100.0 - (df['defect_rate'] * 10.0), 0.0, 100.0).round(2)

    # Final Composite Score:
    # 60% On-Time Delivery Rate + 40% Quality Score
    df['final_score'] = ((df['on_time_rate'] * 0.60) + (df['quality_score'] * 0.40)).round(2)

    # Grade Assignment:
    # Grade A >= 90, B >= 75, C >= 60, D < 60
    conditions = [
        (df['final_score'] >= 90.0),
        (df['final_score'] >= 75.0) & (df['final_score'] < 90.0),
        (df['final_score'] >= 60.0) & (df['final_score'] < 75.0),
        (df['final_score'] < 60.0)
    ]
    grades = ['A', 'B', 'C', 'D']
    df['final_grade'] = np.select(conditions, grades, default='D')
    df['rating'] = df['final_grade']

    df['avg_lead_time_days'] = df['avg_lead_time_days'].round(1)
    df['total_spend'] = df['total_spend'].round(2)

    # Sort descending by final score
    df = df.sort_values(by='final_score', ascending=False).reset_index(drop=True)

    # 3. Update SQLite suppliers table rating column
    cursor = conn.cursor()
    for _, row in df.iterrows():
        cursor.execute(
            "UPDATE suppliers SET rating = ? WHERE id = ?",
            (row['final_grade'], row['supplier_id'])
        )
    conn.commit()
    print("Updated rating column in SQLite suppliers table.")

    # 4. Refresh SQLite View
    cursor.execute("DROP VIEW IF EXISTS supplier_scorecard_view;")
    cursor.execute("""
    CREATE VIEW supplier_scorecard_view AS
    SELECT 
        s.id AS supplier_id,
        s.name AS supplier_name,
        s.category,
        s.location,
        s.rating AS final_grade,
        COUNT(po.id) AS total_orders,
        SUM(po.qty) AS total_qty,
        SUM(d.delivered_qty) AS delivered_qty,
        SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
        COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
        ROUND(AVG(julianday(po.expected_date) - julianday(po.order_date)), 1) AS avg_lead_time_days,
        ROUND(SUM(po.cost), 2) AS total_spend
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty
        FROM defects
        GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY s.id, s.name, s.category, s.location, s.rating;
    """)
    conn.commit()
    print("Refreshed SQLite View: supplier_scorecard_view")

    # 5. Export final_scorecard_with_rating.csv (50 rows)
    export_cols = [
        'supplier_id', 'supplier_name', 'category', 'location',
        'total_orders', 'total_qty', 'delivered_qty',
        'on_time_orders', 'late_orders', 'on_time_rate',
        'defect_qty', 'defect_rate', 'avg_lead_time_days',
        'total_spend', 'quality_score', 'final_score', 'final_grade', 'rating'
    ]
    csv_out_path = os.path.join(CLEANED_DIR, 'final_scorecard_with_rating.csv')
    df[export_cols].to_csv(csv_out_path, index=False)
    print(f"Exported {len(df)} rows to: {csv_out_path}")

    # Also keep final_scorecard.csv updated for compatibility
    legacy_csv = os.path.join(CLEANED_DIR, 'final_scorecard.csv')
    df[export_cols].to_csv(legacy_csv, index=False)

    # Grade distribution summary
    grade_counts = df['final_grade'].value_counts().reindex(['A', 'B', 'C', 'D'], fill_value=0)
    print("\n--- GRADE DISTRIBUTION SUMMARY ---")
    for grade, count in grade_counts.items():
        pct = (count / len(df)) * 100
        print(f"  Grade {grade}: {count:>2} suppliers ({pct:>5.1f}%)")

    # 6. Export EXACT 3-Sheet Excel Workbook for Power BI: powerbi/dashboard_data.xlsx
    print("\nGenerating 3-sheet Power BI Excel workbook...")

    # Sheet 1: Supplier_Scorecard (50 rows)
    df_sheet1 = df[export_cols].copy()

    # Sheet 2: Purchase_Orders (3,000 rows with delivery & defect details)
    q_orders = """
    SELECT 
        po.id AS order_id,
        po.supplier_id,
        s.name AS supplier_name,
        s.category,
        s.location,
        s.rating AS supplier_grade,
        po.order_date,
        po.expected_date,
        d.actual_date AS actual_delivery_date,
        ROUND(julianday(po.expected_date) - julianday(po.order_date), 0) AS lead_time_days,
        d.status AS delivery_status,
        po.qty AS order_qty,
        d.delivered_qty,
        po.cost AS total_cost,
        COALESCE(df.defect_qty, 0) AS defect_qty,
        CASE 
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 7 THEN '0-7 days'
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 30 THEN '8-30 days'
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 90 THEN '31-90 days'
            ELSE '91-180 days'
        END AS lead_time_bucket
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty
        FROM defects
        GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    ORDER BY po.order_date, po.id;
    """
    df_sheet2 = pd.read_sql_query(q_orders, conn)

    # Sheet 3: Monthly_Category_Summary
    q_monthly_cat = """
    SELECT 
        strftime('%Y-%m', po.order_date) AS order_month,
        s.category,
        COUNT(po.id) AS total_orders,
        ROUND(SUM(po.cost), 2) AS monthly_spend,
        SUM(po.qty) AS total_ordered_qty,
        SUM(d.delivered_qty) AS total_delivered_qty,
        SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
        COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
        ROUND(AVG(julianday(po.expected_date) - julianday(po.order_date)), 1) AS avg_lead_time_days
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty
        FROM defects
        GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY order_month, s.category
    ORDER BY order_month, s.category;
    """
    df_sheet3 = pd.read_sql_query(q_monthly_cat, conn)

    excel_path = os.path.join(POWERBI_DIR, 'dashboard_data.xlsx')
    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        df_sheet1.to_excel(writer, sheet_name='Supplier_Scorecard', index=False)
        df_sheet2.to_excel(writer, sheet_name='Purchase_Orders', index=False)
        df_sheet3.to_excel(writer, sheet_name='Monthly_Category_Summary', index=False)

    print(f"Exported EXACT 3-sheet Power BI Excel to: {excel_path}")
    print(f"  Sheet 1: Supplier_Scorecard ({len(df_sheet1)} rows)")
    print(f"  Sheet 2: Purchase_Orders ({len(df_sheet2)} rows)")
    print(f"  Sheet 3: Monthly_Category_Summary ({len(df_sheet3)} rows)")

    conn.close()
    print("=" * 80)
    print("SCORECARD LOGIC EXECUTION COMPLETE")
    print("=" * 80)

if __name__ == '__main__':
    compute_scorecard()

#!/usr/bin/env python3
"""
python/export_dashboard_json.py
DA-32: Exports all analytics from supply_chain.db -> dashboard/data.js
Enriched with: top/bottom suppliers, regional data, rolling KPIs, defect type details.
"""

import os, json, sqlite3
import pandas as pd

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DB_PATH  = os.path.join(BASE_DIR, 'data', 'supply_chain.db')
DATA_JS  = os.path.join(BASE_DIR, 'dashboard', 'data.js')
os.makedirs(os.path.dirname(DATA_JS), exist_ok=True)

def q(conn, sql):
    return pd.read_sql_query(sql, conn).to_dict(orient='records')

def export_data():
    conn = sqlite3.connect(DB_PATH)

    # ── 1. Global KPIs ────────────────────────────────────────────────────────
    kpi = pd.read_sql_query("""
        SELECT
            COUNT(DISTINCT s.id)        AS total_suppliers,
            COUNT(po.id)                AS total_orders,
            ROUND(SUM(po.cost),2)       AS total_spend,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS global_on_time_rate,
            ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1)                 AS global_late_rate,
            ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2)                           AS global_defect_rate,
            ROUND(AVG(julianday(po.expected_date)-julianday(po.order_date)),1)                            AS avg_lead_time_days,
            SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)   AS total_late_orders,
            COALESCE(SUM(df.defect_qty),0)                      AS total_defect_qty,
            SUM(d.delivered_qty)                                AS total_delivered_qty,
            ROUND(SUM(po.cost)/10000000,2)                      AS total_spend_crore
        FROM suppliers s
        JOIN purchase_orders po ON s.id=po.supplier_id
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id;
    """, conn).to_dict(orient='records')[0]

    grades = pd.read_sql_query("SELECT rating,COUNT(*) as count FROM suppliers GROUP BY rating;", conn)
    gd = grades.set_index('rating')['count'].to_dict()
    kpi['grade_counts'] = {g: int(gd.get(g,0)) for g in ['A','B','C','D']}

    # ── 2. Lead Time Buckets ──────────────────────────────────────────────────
    lead_buckets = q(conn, """
        SELECT
            CASE
                WHEN (julianday(po.expected_date)-julianday(po.order_date))<=7  THEN '0-7 days'
                WHEN (julianday(po.expected_date)-julianday(po.order_date))<=30 THEN '8-30 days'
                WHEN (julianday(po.expected_date)-julianday(po.order_date))<=90 THEN '31-90 days'
                ELSE '91-180 days'
            END AS bucket,
            COUNT(po.id) AS total_orders,
            SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
            SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)                  AS late_orders,
            ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS late_rate
        FROM purchase_orders po
        JOIN deliveries d ON po.id=d.order_id
        GROUP BY bucket
        ORDER BY CASE bucket WHEN '0-7 days' THEN 1 WHEN '8-30 days' THEN 2 WHEN '31-90 days' THEN 3 ELSE 4 END;
    """)

    # ── 3. Categories ─────────────────────────────────────────────────────────
    categories = q(conn, """
        SELECT s.category,
            COUNT(DISTINCT s.id) AS supplier_count,
            COUNT(po.id)         AS order_volume,
            ROUND(SUM(po.cost),2)  AS total_spend,
            ROUND(AVG(po.cost),2)  AS avg_po_cost,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS on_time_rate,
            ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1)                 AS late_rate,
            ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2)                           AS defect_rate,
            COALESCE(SUM(df.defect_qty),0) AS total_defect_qty,
            SUM(d.delivered_qty)           AS delivered_qty
        FROM suppliers s
        JOIN purchase_orders po ON s.id=po.supplier_id
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
        GROUP BY s.category
        ORDER BY total_spend DESC;
    """)

    # ── 4. Monthly Trends ─────────────────────────────────────────────────────
    monthly = q(conn, """
        SELECT
            strftime('%Y-%m', po.order_date) AS month,
            COUNT(po.id)  AS total_orders,
            SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END) AS late_orders,
            ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1)                 AS late_rate,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS on_time_rate,
            COALESCE(SUM(df.defect_qty),0) AS defects,
            ROUND(SUM(po.cost),2)          AS spend
        FROM purchase_orders po
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
        GROUP BY month ORDER BY month;
    """)

    # ── 5. Defect Types ───────────────────────────────────────────────────────
    defect_types = q(conn, """
        SELECT type AS defect_type,
            COUNT(id)       AS incident_count,
            SUM(defect_qty) AS total_units,
            ROUND(SUM(defect_qty)*100.0/(SELECT SUM(defect_qty) FROM defects),1) AS pct_share,
            ROUND(AVG(defect_qty),1) AS avg_per_incident
        FROM defects GROUP BY type ORDER BY total_units DESC;
    """)

    # ── 6. Regional / Location Analysis ──────────────────────────────────────
    locations = q(conn, """
        SELECT s.location,
            COUNT(DISTINCT s.id) AS suppliers,
            COUNT(po.id)         AS orders,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS on_time_rate,
            ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1)                 AS late_rate,
            ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2)                           AS defect_rate,
            ROUND(SUM(po.cost),2) AS total_spend
        FROM suppliers s
        JOIN purchase_orders po ON s.id=po.supplier_id
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
        GROUP BY s.location ORDER BY late_rate DESC;
    """)

    # ── 7. Full Scorecard (50 rows) ───────────────────────────────────────────
    scorecard = pd.read_csv(os.path.join(BASE_DIR,'data','cleaned','final_scorecard_with_rating.csv')).to_dict(orient='records')

    # ── 8. Top 5 Star Suppliers (Grade A) ─────────────────────────────────────
    top_suppliers = q(conn, """
        SELECT s.id AS supplier_id, s.name AS supplier_name, s.category, s.location, s.rating AS grade,
            COUNT(po.id) AS total_orders,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS on_time_rate,
            ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) AS defect_rate,
            ROUND(SUM(po.cost)/100000,1) AS spend_lakhs
        FROM suppliers s
        JOIN purchase_orders po ON s.id=po.supplier_id
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
        WHERE s.rating='A'
        GROUP BY s.id ORDER BY on_time_rate DESC LIMIT 5;
    """)

    # ── 9. Worst Performers (Grade C & D) ─────────────────────────────────────
    bottom_suppliers = q(conn, """
        SELECT s.id AS supplier_id, s.name AS supplier_name, s.category, s.location, s.rating AS grade,
            COUNT(po.id) AS total_orders,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime','On-Time') THEN 1 ELSE 0 END)*100.0/COUNT(po.id),1) AS on_time_rate,
            ROUND(COALESCE(SUM(df.defect_qty),0)*100.0/SUM(d.delivered_qty),2) AS defect_rate,
            ROUND(SUM(po.cost)/100000,1) AS spend_lakhs
        FROM suppliers s
        JOIN purchase_orders po ON s.id=po.supplier_id
        JOIN deliveries d ON po.id=d.order_id
        LEFT JOIN (SELECT delivery_id,SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id) df ON d.id=df.delivery_id
        WHERE s.rating IN ('C','D')
        GROUP BY s.id ORDER BY on_time_rate ASC LIMIT 8;
    """)

    # ── 10. Rolling 3-Month Late Rate (for monthly chart overlay) ─────────────
    rolling = q(conn, """
        WITH mm AS (
            SELECT strftime('%Y-%m',po.order_date) AS month,
                COUNT(po.id) AS orders,
                ROUND(SUM(CASE WHEN d.status='Late' THEN 1 ELSE 0 END)*100.0/COUNT(po.id),2) AS late_rate
            FROM purchase_orders po
            JOIN deliveries d ON po.id=d.order_id
            GROUP BY month
        )
        SELECT month, orders, late_rate,
            ROUND(AVG(late_rate) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),2) AS rolling_3m
        FROM mm ORDER BY month;
    """)

    # ── 11. Data Explorer Samples ─────────────────────────────────────────────
    sup_sample = q(conn, "SELECT id,name,category,location,rating FROM suppliers ORDER BY id;")
    po_sample  = q(conn, "SELECT id,supplier_id,order_date,expected_date,qty,cost FROM purchase_orders ORDER BY id LIMIT 500;")
    del_sample = q(conn, "SELECT id,order_id,actual_date,status,delivered_qty FROM deliveries ORDER BY id LIMIT 500;")
    def_sample = q(conn, "SELECT id,delivery_id,defect_qty,type FROM defects ORDER BY id LIMIT 500;")

    conn.close()

    payload = {
        'kpi': kpi,
        'leadTimeBuckets': lead_buckets,
        'categories': categories,
        'monthly': monthly,
        'rolling': rolling,
        'defectTypes': defect_types,
        'locations': locations,
        'scorecard': scorecard,
        'topSuppliers': top_suppliers,
        'bottomSuppliers': bottom_suppliers,
        'suppliers_sample': sup_sample,
        'po_sample': po_sample,
        'deliveries_sample': del_sample,
        'defects_sample': def_sample,
    }

    with open(DATA_JS, 'w', encoding='utf-8') as f:
        f.write("/* Auto-generated by DA-32 export_dashboard_json.py */\n")
        f.write("window.SCORECARD_DATA = ")
        json.dump(payload, f, indent=2, default=str)
        f.write(";\n")

    print(f"Exported dashboard JSON -> {DATA_JS}  ({os.path.getsize(DATA_JS):,} bytes)")

if __name__ == '__main__':
    export_data()

#!/usr/bin/env python3
"""
python/run_sql.py
DA-32: Supplier Performance Scorecard SQL Analytical Suite
Stack: SQL (SQLite) + Python + Power BI

Runs 12 comprehensive analytical queries demonstrating:
- JOIN (INNER, LEFT)
- GROUP BY & HAVING
- CASE WHEN conditional expressions
- CTE (Common Table Expressions)
- Window Functions (DENSE_RANK, ROW_NUMBER, SUM OVER, AVG OVER, LAG)
"""

import os
import sqlite3
import pandas as pd

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DB_PATH = os.path.join(BASE_DIR, 'data', 'supply_chain.db')

def execute_queries():
    print("=" * 95)
    print("DA-32: SUPPLIER PERFORMANCE SCORECARD - SQL ANALYTICAL ENGINE")
    print(f"Database: {DB_PATH}")
    print("=" * 95)

    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"Database not found at {DB_PATH}. Run create_db.py first.")

    conn = sqlite3.connect(DB_PATH)

    # --------------------------------------------------------------------------
    # QUERY 1: GLOBAL EXECUTIVE SUPPLY CHAIN METRICS (JOIN, CASE, AGGREGATE)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 1] GLOBAL EXECUTIVE SUPPLY CHAIN METRICS (JOIN, CASE, AGGREGATE)")
    print("#" * 95)
    q1 = """
    SELECT 
        COUNT(DISTINCT s.id) AS total_suppliers,
        COUNT(po.id) AS total_orders,
        ROUND(SUM(po.cost), 2) AS total_spend_inr,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS global_on_time_rate_pct,
        ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS global_late_rate_pct,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS global_defect_rate_pct,
        ROUND(AVG(julianday(po.expected_date) - julianday(po.order_date)), 1) AS avg_lead_time_days
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
    ) df ON d.id = df.delivery_id;
    """
    df1 = pd.read_sql_query(q1, conn)
    print(df1.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 2: LEAD TIME BUCKET VS. LATE DELIVERY RISK (CASE, GROUP BY, JOIN)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 2] LEAD TIME BUCKET VS. LATE DELIVERY RISK (CASE, GROUP BY, JOIN)")
    print("#" * 95)
    q2 = """
    SELECT 
        CASE 
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 7 THEN '0-7 days'
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 30 THEN '8-30 days'
            WHEN (julianday(po.expected_date) - julianday(po.order_date)) <= 90 THEN '31-90 days'
            ELSE '91-180 days'
        END AS lead_time_bucket,
        COUNT(po.id) AS total_orders,
        SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS late_delivery_rate_pct,
        ROUND(AVG(po.cost), 2) AS avg_po_cost
    FROM purchase_orders po
    JOIN deliveries d ON po.id = d.order_id
    GROUP BY lead_time_bucket
    ORDER BY 
        CASE lead_time_bucket
            WHEN '0-7 days' THEN 1
            WHEN '8-30 days' THEN 2
            WHEN '31-90 days' THEN 3
            ELSE 4
        END;
    """
    df2 = pd.read_sql_query(q2, conn)
    print(df2.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 3: CATEGORY VULNERABILITY & SLA COMPLIANCE (GROUP BY, JOIN, CASE)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 3] CATEGORY PERFORMANCE & DEFECT VULNERABILITY (GROUP BY, JOIN, CASE)")
    print("#" * 95)
    q3 = """
    SELECT 
        s.category,
        COUNT(DISTINCT s.id) AS supplier_count,
        COUNT(po.id) AS order_volume,
        ROUND(SUM(po.cost), 2) AS total_spend_inr,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate_pct,
        ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS late_rate_pct,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate_pct,
        COALESCE(SUM(df.defect_qty), 0) AS total_defects
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY s.category
    ORDER BY total_spend_inr DESC;
    """
    df3 = pd.read_sql_query(q3, conn)
    print(df3.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 4: THE DEFECT PARADOX (HIGH SPEND VS DEFECT FREQUENCY)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 4] THE DEFECT PARADOX: CAPITAL SPEND VS DEFECT EXPOSURE")
    print("#" * 95)
    q4 = """
    SELECT 
        s.category,
        ROUND(AVG(po.cost), 2) AS avg_po_value,
        ROUND(SUM(po.cost), 2) AS category_spend,
        ROUND(SUM(po.cost) * 100.0 / (SELECT SUM(cost) FROM purchase_orders), 1) AS pct_total_spend,
        COALESCE(SUM(df.defect_qty), 0) AS total_defects,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate_pct,
        ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS late_rate_pct
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY s.category
    ORDER BY category_spend DESC;
    """
    df4 = pd.read_sql_query(q4, conn)
    print(df4.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 5: MONTHLY DELIVERY & LATENCY TRENDS (CTE, strftime, JOIN, GROUP BY)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 5] MONTHLY DELIVERY TRENDS & SEASONALITY (CTE, strftime, JOIN)")
    print("#" * 95)
    q5 = """
    WITH MonthlyMetrics AS (
        SELECT 
            strftime('%Y-%m', po.order_date) AS order_month,
            COUNT(po.id) AS total_orders,
            ROUND(SUM(po.cost), 2) AS monthly_spend,
            SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
            SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
            COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
            SUM(d.delivered_qty) AS delivered_qty
        FROM purchase_orders po
        JOIN deliveries d ON po.id = d.order_id
        LEFT JOIN (
            SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
        ) df ON d.id = df.delivery_id
        GROUP BY order_month
    )
    SELECT 
        order_month,
        total_orders,
        monthly_spend,
        late_orders,
        ROUND(late_orders * 100.0 / total_orders, 2) AS late_rate_pct,
        ROUND(defect_qty * 100.0 / delivered_qty, 2) AS defect_rate_pct
    FROM MonthlyMetrics
    ORDER BY order_month
    LIMIT 12;
    """
    df5 = pd.read_sql_query(q5, conn)
    print(df5.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 6: CATEGORY SUPPLIER RANKING (WINDOW FUNCTION: DENSE_RANK & PARTITION BY)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 6] CATEGORY SUPPLIER RANKING (WINDOW FUNCTION: DENSE_RANK & PARTITION BY)")
    print("#" * 95)
    q6 = """
    WITH SupplierAgg AS (
        SELECT 
            s.id AS supplier_id,
            s.name AS supplier_name,
            s.category,
            COUNT(po.id) AS orders,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
            ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
            ROUND(SUM(po.cost), 2) AS spend
        FROM suppliers s
        JOIN purchase_orders po ON s.id = po.supplier_id
        JOIN deliveries d ON po.id = d.order_id
        LEFT JOIN (
            SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
        ) df ON d.id = df.delivery_id
        GROUP BY s.id, s.name, s.category
    ),
    RankedSuppliers AS (
        SELECT 
            category,
            DENSE_RANK() OVER (PARTITION BY category ORDER BY on_time_rate DESC, defect_rate ASC) AS rank_in_cat,
            supplier_id,
            supplier_name,
            on_time_rate,
            defect_rate,
            spend
        FROM SupplierAgg
    )
    SELECT 
        category,
        rank_in_cat,
        supplier_id,
        supplier_name,
        on_time_rate,
        defect_rate,
        spend
    FROM RankedSuppliers
    WHERE rank_in_cat <= 2
    ORDER BY category, rank_in_cat;
    """
    df6 = pd.read_sql_query(q6, conn)
    print(df6.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 7: STAR SUPPLIERS (GRADE A) WITH RUNNING CUMULATIVE SPEND (WINDOW: SUM OVER)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 7] STAR SUPPLIERS (GRADE A) WITH CUMULATIVE RUNNING SPEND (WINDOW FUNCTION)")
    print("#" * 95)
    q7 = """
    WITH StarSuppliers AS (
        SELECT 
            s.id AS supplier_id,
            s.name AS supplier_name,
            s.category,
            s.rating AS grade,
            COUNT(po.id) AS total_orders,
            ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
            ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
            ROUND(SUM(po.cost), 2) AS spend
        FROM suppliers s
        JOIN purchase_orders po ON s.id = po.supplier_id
        JOIN deliveries d ON po.id = d.order_id
        LEFT JOIN (
            SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
        ) df ON d.id = df.delivery_id
        WHERE s.rating = 'A'
        GROUP BY s.id, s.name, s.category, s.rating
    )
    SELECT 
        supplier_id,
        supplier_name,
        category,
        grade,
        on_time_rate,
        defect_rate,
        spend,
        SUM(spend) OVER (ORDER BY spend DESC) AS cumulative_spend,
        ROUND(SUM(spend) OVER (ORDER BY spend DESC) * 100.0 / (SELECT SUM(cost) FROM purchase_orders), 2) AS cumulative_spend_pct_total
    FROM StarSuppliers
    ORDER BY spend DESC;
    """
    df7 = pd.read_sql_query(q7, conn)
    print(df7.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 8: CHRONIC FAILING & HIGH-RISK SUPPLIERS (GRADE C & D)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 8] CHRONIC FAILING & HIGH-RISK SUPPLIERS (GRADE C & D)")
    print("#" * 95)
    q8 = """
    SELECT 
        s.id AS supplier_id,
        s.name AS supplier_name,
        s.category,
        s.location,
        s.rating AS grade,
        COUNT(po.id) AS total_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
        ROUND(SUM(po.cost), 2) AS total_spend
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    WHERE s.rating IN ('C', 'D')
    GROUP BY s.id, s.name, s.category, s.location, s.rating
    ORDER BY grade DESC, on_time_rate ASC;
    """
    df8 = pd.read_sql_query(q8, conn)
    print(df8.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 9: ROOT CAUSE DEFECT TYPES WITH WINDOW PERCENTAGE SHARE
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 9] DEFECT TYPES ROOT CAUSE WITH WINDOW PERCENTAGE SHARE")
    print("#" * 95)
    q9 = """
    WITH DefectSummary AS (
        SELECT 
            type AS defect_type,
            COUNT(id) AS defect_incidents,
            SUM(defect_qty) AS total_defective_units,
            ROUND(AVG(defect_qty), 1) AS avg_defect_units_per_incident
        FROM defects
        GROUP BY type
    )
    SELECT 
        defect_type,
        defect_incidents,
        total_defective_units,
        ROUND(total_defective_units * 100.0 / SUM(total_defective_units) OVER (), 2) AS pct_of_all_defects,
        avg_defect_units_per_incident
    FROM DefectSummary
    ORDER BY total_defective_units DESC;
    """
    df9 = pd.read_sql_query(q9, conn)
    print(df9.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 10: ROLLING 3-MONTH MOVING AVERAGE OF LATE DELIVERY RATE (WINDOW: ROWS PRECEDING)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 10] ROLLING 3-MONTH MOVING AVERAGE OF LATE RATE (WINDOW: ROWS BETWEEN)")
    print("#" * 95)
    q10 = """
    WITH MonthlyStats AS (
        SELECT 
            strftime('%Y-%m', po.order_date) AS month,
            COUNT(po.id) AS orders,
            ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS monthly_late_rate
        FROM purchase_orders po
        JOIN deliveries d ON po.id = d.order_id
        GROUP BY month
    )
    SELECT 
        month,
        orders,
        monthly_late_rate,
        ROUND(AVG(monthly_late_rate) OVER (
            ORDER BY month 
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 2) AS rolling_3m_avg_late_rate,
        ROUND(LAG(monthly_late_rate, 1) OVER (ORDER BY month), 2) AS prev_month_late_rate
    FROM MonthlyStats
    ORDER BY month
    LIMIT 12;
    """
    df10 = pd.read_sql_query(q10, conn)
    print(df10.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 11: SUPPLIER VOLUME TIER SEGMENTATION (CTE, CASE, GROUP BY)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 11] SUPPLIER ORDER VOLUME SEGMENTATION & DISPARITY (CTE, CASE)")
    print("#" * 95)
    q11 = """
    WITH SupplierTotals AS (
        SELECT 
            s.id AS supplier_id,
            COUNT(po.id) AS order_count,
            SUM(po.cost) AS spend,
            SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
            COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
            SUM(d.delivered_qty) AS delivered_qty
        FROM suppliers s
        JOIN purchase_orders po ON s.id = po.supplier_id
        JOIN deliveries d ON po.id = d.order_id
        LEFT JOIN (
            SELECT delivery_id, SUM(defect_qty) AS defect_qty FROM defects GROUP BY delivery_id
        ) df ON d.id = df.delivery_id
        GROUP BY s.id
    ),
    VolumeTiers AS (
        SELECT 
            supplier_id,
            order_count,
            spend,
            on_time_orders,
            defect_qty,
            delivered_qty,
            CASE 
                WHEN order_count >= 65 THEN 'High Volume (>=65 orders)'
                WHEN order_count >= 55 THEN 'Medium Volume (55-64 orders)'
                ELSE 'Low Volume (<55 orders)'
            END AS volume_tier
        FROM SupplierTotals
    )
    SELECT 
        volume_tier,
        COUNT(supplier_id) AS supplier_count,
        SUM(order_count) AS total_orders,
        ROUND(SUM(spend), 2) AS total_tier_spend,
        ROUND(SUM(on_time_orders) * 100.0 / SUM(order_count), 2) AS tier_on_time_rate,
        ROUND(SUM(defect_qty) * 100.0 / SUM(delivered_qty), 2) AS tier_defect_rate
    FROM VolumeTiers
    GROUP BY volume_tier
    ORDER BY total_orders DESC;
    """
    df11 = pd.read_sql_query(q11, conn)
    print(df11.to_string(index=False))

    # --------------------------------------------------------------------------
    # QUERY 12: SUPPLIER LEAD TIME ANOMALIES & CATEGORY BENCHMARK (WINDOW OVER ALL)
    # --------------------------------------------------------------------------
    print("\n" + "#" * 95)
    print("[QUERY 12] LEAD TIME ANOMALIES VS CATEGORY BENCHMARK (WINDOW FUNCTIONS)")
    print("#" * 95)
    q12 = """
    WITH SupplierLeadTimes AS (
        SELECT 
            s.id AS supplier_id,
            s.name AS supplier_name,
            s.category,
            s.rating,
            ROUND(AVG(julianday(po.expected_date) - julianday(po.order_date)), 1) AS supplier_avg_lead_time,
            ROUND(SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS late_rate
        FROM suppliers s
        JOIN purchase_orders po ON s.id = po.supplier_id
        JOIN deliveries d ON po.id = d.order_id
        GROUP BY s.id, s.name, s.category, s.rating
    ),
    BenchmarkComparison AS (
        SELECT 
            supplier_id,
            supplier_name,
            category,
            rating,
            supplier_avg_lead_time,
            ROUND(AVG(supplier_avg_lead_time) OVER (PARTITION BY category), 1) AS category_avg_lead_time,
            late_rate
        FROM SupplierLeadTimes
    )
    SELECT 
        supplier_id,
        supplier_name,
        category,
        rating,
        supplier_avg_lead_time,
        category_avg_lead_time,
        ROUND(supplier_avg_lead_time - category_avg_lead_time, 1) AS lead_time_variance_vs_category,
        late_rate
    FROM BenchmarkComparison
    WHERE rating IN ('A', 'D')
    ORDER BY category, rating, supplier_avg_lead_time DESC;
    """
    df12 = pd.read_sql_query(q12, conn)
    print(df12.to_string(index=False))

    conn.close()
    print("\n" + "=" * 95)
    print("ALL 12 SQL QUERIES EXECUTED SUCCESSFULLY ON SQLite (supply_chain.db)")
    print("=" * 95)

if __name__ == '__main__':
    execute_queries()

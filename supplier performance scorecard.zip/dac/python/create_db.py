#!/usr/bin/env python3
"""
python/create_db.py
DA-32: Supplier Performance Scorecard SQLite Database Ingestion
Stack: SQL (SQLite) + Python + Power BI

Database: C:\\dac\\data\\supply_chain.db
Tables:
- suppliers(id, name, category, location, rating)
- purchase_orders(id, supplier_id, order_date, expected_date, qty, cost)
- deliveries(id, order_id, actual_date, status, delivered_qty)  -- status: OnTime / Late
- defects(id, delivery_id, defect_qty, type)
"""

import os
import sqlite3
import pandas as pd

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
DATA_DIR = os.path.join(BASE_DIR, 'data')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
DB_PATH = os.path.join(DATA_DIR, 'supply_chain.db')

def create_database():
    print("=" * 80)
    print("DA-32: CREATING / POPULATING SQLite DATABASE")
    print(f"Target DB: {DB_PATH}")
    print("=" * 80)

    os.makedirs(DATA_DIR, exist_ok=True)

    # Remove existing db for clean, pristine rebuild
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
            print("Reset existing supply_chain.db for clean initialization.")
        except Exception as e:
            print(f"Notice: overwrite mode ({e}).")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Enable foreign key support
    cursor.execute("PRAGMA foreign_keys = ON;")

    # 1. Create Schema
    cursor.executescript("""
    DROP VIEW IF EXISTS supplier_scorecard_view;
    DROP VIEW IF EXISTS v_defects;
    DROP VIEW IF EXISTS v_deliveries;
    DROP VIEW IF EXISTS v_purchase_orders;
    DROP VIEW IF EXISTS v_suppliers;

    DROP TABLE IF EXISTS defects;
    DROP TABLE IF EXISTS deliveries;
    DROP TABLE IF EXISTS purchase_orders;
    DROP TABLE IF EXISTS suppliers;

    -- 1. Suppliers Table
    CREATE TABLE suppliers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        location TEXT NOT NULL,
        rating TEXT
    );

    -- 2. Purchase Orders Table
    CREATE TABLE purchase_orders (
        id TEXT PRIMARY KEY,
        supplier_id TEXT NOT NULL,
        order_date TEXT NOT NULL,
        expected_date TEXT NOT NULL,
        qty INTEGER NOT NULL,
        cost REAL NOT NULL,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
    );

    -- 3. Deliveries Table
    CREATE TABLE deliveries (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL,
        actual_date TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('OnTime', 'Late', 'On-Time')),
        delivered_qty INTEGER NOT NULL,
        FOREIGN KEY (order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
    );

    -- 4. Defects Table
    CREATE TABLE defects (
        id TEXT PRIMARY KEY,
        delivery_id TEXT NOT NULL,
        defect_qty INTEGER NOT NULL,
        type TEXT NOT NULL,
        FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE
    );

    -- Indexes for high-speed analytical joins and aggregations
    CREATE INDEX idx_po_supplier ON purchase_orders(supplier_id);
    CREATE INDEX idx_po_dates ON purchase_orders(order_date, expected_date);
    CREATE INDEX idx_deliveries_order ON deliveries(order_id);
    CREATE INDEX idx_deliveries_status ON deliveries(status);
    CREATE INDEX idx_defects_delivery ON defects(delivery_id);

    -- Compatibility Views for alternate naming conventions
    CREATE VIEW v_suppliers AS 
    SELECT id AS supplier_id, id, name AS supplier_name, name, category, location, rating FROM suppliers;

    CREATE VIEW v_purchase_orders AS 
    SELECT id AS order_id, id, supplier_id, order_date, expected_date, qty AS quantity, qty, cost FROM purchase_orders;

    CREATE VIEW v_deliveries AS 
    SELECT id AS delivery_id, id, order_id, actual_date AS actual_delivery_date, actual_date, delivered_qty, status AS delivery_status, status FROM deliveries;

    CREATE VIEW v_defects AS 
    SELECT id AS defect_id, id, delivery_id, defect_qty, type AS defect_type, type FROM defects;
    """)
    conn.commit()
    print("Schema and views initialized successfully.")

    # 2. Ingest CSV Data
    # 2.1 Suppliers
    sup_csv = os.path.join(RAW_DIR, 'suppliers.csv')
    df_sup = pd.read_csv(sup_csv)
    # Support both id/name or supplier_id/supplier_name in CSV
    rename_sup = {'supplier_id': 'id', 'supplier_name': 'name'}
    df_sup = df_sup.rename(columns=rename_sup)
    df_sup[['id', 'name', 'category', 'location', 'rating']].to_sql('suppliers', conn, if_exists='append', index=False)
    print(f"Loaded {len(df_sup)} rows into 'suppliers'")

    # 2.2 Purchase Orders
    po_csv = os.path.join(RAW_DIR, 'purchase_orders.csv')
    df_po = pd.read_csv(po_csv)
    rename_po = {'order_id': 'id', 'quantity': 'qty'}
    df_po = df_po.rename(columns=rename_po)
    df_po[['id', 'supplier_id', 'order_date', 'expected_date', 'qty', 'cost']].to_sql('purchase_orders', conn, if_exists='append', index=False)
    print(f"Loaded {len(df_po)} rows into 'purchase_orders'")

    # 2.3 Deliveries
    del_csv = os.path.join(RAW_DIR, 'deliveries.csv')
    df_del = pd.read_csv(del_csv)
    rename_del = {
        'delivery_id': 'id',
        'actual_delivery_date': 'actual_date',
        'delivery_status': 'status'
    }
    df_del = df_del.rename(columns=rename_del)
    # Standardize status to OnTime / Late
    df_del['status'] = df_del['status'].replace({'On-Time': 'OnTime'})
    df_del[['id', 'order_id', 'actual_date', 'status', 'delivered_qty']].to_sql('deliveries', conn, if_exists='append', index=False)
    print(f"Loaded {len(df_del)} rows into 'deliveries'")

    # 2.4 Defects
    def_csv = os.path.join(RAW_DIR, 'defects.csv')
    df_def = pd.read_csv(def_csv)
    rename_def = {'defect_id': 'id', 'defect_type': 'type'}
    df_def = df_def.rename(columns=rename_def)
    df_def[['id', 'delivery_id', 'defect_qty', 'type']].to_sql('defects', conn, if_exists='append', index=False)
    print(f"Loaded {len(df_def)} rows into 'defects'")

    # 3. Create Primary Analytics View
    cursor.execute("""
    CREATE VIEW supplier_scorecard_view AS
    SELECT 
        s.id AS supplier_id,
        s.name AS supplier_name,
        s.category,
        s.location,
        s.rating AS final_grade,
        COUNT(po.id) AS total_orders,
        SUM(po.qty) AS total_qty,
        SUM(d.delivered_qty) AS delivered_qty,
        SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) AS on_time_orders,
        SUM(CASE WHEN d.status = 'Late' THEN 1 ELSE 0 END) AS late_orders,
        ROUND(SUM(CASE WHEN d.status IN ('OnTime', 'On-Time') THEN 1 ELSE 0 END) * 100.0 / COUNT(po.id), 2) AS on_time_rate,
        COALESCE(SUM(df.defect_qty), 0) AS defect_qty,
        ROUND(COALESCE(SUM(df.defect_qty), 0) * 100.0 / SUM(d.delivered_qty), 2) AS defect_rate,
        ROUND(AVG(julianday(po.expected_date) - julianday(po.order_date)), 1) AS avg_lead_time_days,
        ROUND(SUM(po.cost), 2) AS total_spend
    FROM suppliers s
    JOIN purchase_orders po ON s.id = po.supplier_id
    JOIN deliveries d ON po.id = d.order_id
    LEFT JOIN (
        SELECT delivery_id, SUM(defect_qty) AS defect_qty
        FROM defects
        GROUP BY delivery_id
    ) df ON d.id = df.delivery_id
    GROUP BY s.id, s.name, s.category, s.location, s.rating;
    """)
    conn.commit()
    print("Created SQLite View: 'supplier_scorecard_view'")

    # Verify Counts
    for tbl in ['suppliers', 'purchase_orders', 'deliveries', 'defects']:
        count = cursor.execute(f"SELECT COUNT(*) FROM {tbl};").fetchone()[0]
        print(f"  Verification -> {tbl}: {count:,} rows")

    conn.close()
    print("=" * 80)
    print("DATABASE SETUP COMPLETE: supply_chain.db READY")
    print("=" * 80)

if __name__ == '__main__':
    create_database()

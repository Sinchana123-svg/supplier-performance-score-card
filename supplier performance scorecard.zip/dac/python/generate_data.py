#!/usr/bin/env python3
"""
python/generate_data.py
DA-32: Supplier Performance Scorecard Data Generator
Stack: SQL (SQLite) + Python + Power BI
50 suppliers, 3,000 orders across 4 industrial categories and 5 Indian hubs

Outputs:
- C:\\dac\\data\\raw\\suppliers.csv (id, name, category, location, rating)
- C:\\dac\\data\\raw\\purchase_orders.csv (id, supplier_id, order_date, expected_date, qty, cost)
- C:\\dac\\data\\raw\\deliveries.csv (id, order_id, actual_date, status, delivered_qty)
- C:\\dac\\data\\raw\\defects.csv (id, delivery_id, defect_qty, type)
"""

import os
import random
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Deterministic seed for exact reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

def get_base_dir():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(current_dir) in ['python', 'sql', 'data', 'powerbi', 'dashboard']:
        return os.path.dirname(current_dir)
    return current_dir

BASE_DIR = get_base_dir()
RAW_DATA_DIR = os.path.join(BASE_DIR, 'data', 'raw')
os.makedirs(RAW_DATA_DIR, exist_ok=True)

print("=" * 80)
print("DA-32: SUPPLIER PERFORMANCE DATASET GENERATION")
print(f"Base Directory: {BASE_DIR}")
print(f"Output Directory: {RAW_DATA_DIR}")
print("=" * 80)

# ---------------------------------------------------------
# 1. GENERATE SUPPLIERS (50 rows)
# Schema: id, name, category, location
# ---------------------------------------------------------
LOCATIONS = ['Bangalore', 'Mumbai', 'Delhi', 'Chennai', 'Pune']
CATEGORIES = ['Raw Materials', 'Electronics', 'Packaging', 'Logistics']

COMPANY_NAMES = {
    'Raw Materials': [
        "Apex Alloy & Steel Ltd", "Bharat Metals & Tubing", "Deccan Precision Forgings",
        "JSW Industrial Sheets", "Tata Special Steels Corp", "Reliance Poly Polymers",
        "Hindalco Fabricators", "Jindal Precision Tubes", "Godrej Industrial Alloys",
        "Murugappa Industrial Foils", "Vedanta Raw Materials Co", "Kalyani Alloy Forge",
        "Mahindra Industrial Steel"
    ],
    'Electronics': [
        "Kaynes Electronics Solutions", "Dixon Technologies India", "Bharat Electronics Spares",
        "Amber Circuit Systems", "Cyient Semiconductor Labs", "Centum Electronics Corp",
        "Syrma SGS Industrial Tech", "VVDN Hardware Systems", "Schneider Electric India",
        "Havells Industrial Sensors", "L&T Micro Controls", "Opto Circuits Components",
        "Honeywell Automation Spares"
    ],
    'Packaging': [
        "Uflex Flexible Pack Ltd", "TCPL Packaging Solutions", "Huhtamaki India Pack",
        "Essel Propack Industries", "Time Technoplast Containers", "Polyplex Packaging Co",
        "Balmer Lawrie Industrial Drums", "Supreme Industries Packaging", "Cosmo First Films Ltd",
        "Mold-Tek Industrial Packaging", "Shish Corrugated Boxes", "EPL Packaging Systems"
    ],
    'Logistics': [
        "Delhivery Express Supply", "Blue Dart Freight Systems", "VRL Industrial Logistics",
        "TCI Express Solutions", "Mahindra Logistics India", "Gati KWE Industrial Movers",
        "Allcargo Global Logistics", "Container Corp India Spares", "Snowman Cold Chain Fleet",
        "TVS Supply Chain Fleet", "Safexpress Freight Lines", "SpotOn Logistics Hub"
    ]
}

# 13 Raw Materials, 13 Electronics, 12 Packaging, 12 Logistics = 50 total
cat_distribution = ['Raw Materials'] * 13 + ['Electronics'] * 13 + ['Packaging'] * 12 + ['Logistics'] * 12
random.shuffle(cat_distribution)

supplier_profiles = {}
suppliers_list = []

for idx, cat in enumerate(cat_distribution, start=1):
    sup_id = f"SUP{idx:03d}"
    name_pool = COMPANY_NAMES[cat]
    name_idx = (idx - 1) % len(name_pool)
    sup_name = name_pool[name_idx]
    if idx > len(name_pool):
        sup_name += f" - Div {idx // len(name_pool) + 1}"

    loc = LOCATIONS[(idx * 7) % len(LOCATIONS)]

    # Calibrate realistic operational profiles
    if sup_id in ['SUP012', 'SUP044']:
        # Chronic failing suppliers (Grade D: high late rate, elevated defect rate)
        base_late_prob = 0.58
        base_defect_prob = 0.058
        init_rating = "D"
    elif sup_id in ['SUP008', 'SUP027', 'SUP041']:
        # At-risk poor suppliers (Grade C/D boundary: ~46% late rate)
        base_late_prob = 0.48
        base_defect_prob = 0.042
        init_rating = "D" if sup_id in ['SUP008', 'SUP041'] else "C"
    elif sup_id in ['SUP001', 'SUP005', 'SUP015', 'SUP023', 'SUP036', 'SUP049']:
        # Star suppliers (Grade A: ~92%+ on-time, ultra-low defects)
        base_late_prob = 0.06
        base_defect_prob = 0.005
        init_rating = "A"
    else:
        # Core reliable suppliers (Grade B / Upper C)
        base_late_prob = random.uniform(0.18, 0.30)
        base_defect_prob = random.uniform(0.012, 0.024)
        init_rating = "B"

    # Category variance factor
    if cat == 'Electronics':
        base_defect_prob *= 1.25
    elif cat == 'Raw Materials':
        base_defect_prob *= 1.10
    elif cat == 'Logistics':
        base_defect_prob *= 0.65

    supplier_profiles[sup_id] = {
        'late_prob': base_late_prob,
        'defect_prob': base_defect_prob,
        'category': cat,
        'location': loc,
        'name': sup_name
    }

    suppliers_list.append({
        'id': sup_id,
        'name': sup_name,
        'category': cat,
        'location': loc,
        'rating': init_rating
    })

df_suppliers = pd.DataFrame(suppliers_list)
suppliers_csv_path = os.path.join(RAW_DATA_DIR, 'suppliers.csv')
df_suppliers.to_csv(suppliers_csv_path, index=False)
print(f"Generated {len(df_suppliers)} suppliers -> {suppliers_csv_path}")

# ---------------------------------------------------------
# 2. GENERATE PURCHASE ORDERS (3,000 rows)
# Schema: id, supplier_id, order_date, expected_date, qty, cost
# ---------------------------------------------------------
all_sup_ids = df_suppliers['id'].tolist()
start_date = datetime(2023, 1, 1)
end_date = datetime(2024, 11, 20)
date_range_days = (end_date - start_date).days

# Target lead time buckets:
# 0-7 days (rush): 360 orders (~12%)
# 8-30 days (standard): 1500 orders (~50%)
# 31-90 days (medium): 780 orders (~26%)
# 91-180 days (long horizon): 360 orders (~12%)
bucket_choices = [
    (0, 7, 360),
    (8, 30, 1500),
    (31, 90, 780),
    (91, 180, 360)
]
lead_time_pool = []
for b_min, b_max, count in bucket_choices:
    lead_time_pool.extend([random.randint(b_min, b_max) for _ in range(count)])
random.shuffle(lead_time_pool)

UNIT_COST_BASE = {
    'Raw Materials': 180.0,
    'Electronics': 320.0,
    'Packaging': 45.0,
    'Logistics': 35.0
}

po_list = []
for i in range(1, 3001):
    po_id = f"PO{10000 + i}"
    # Even balanced allocation across all 50 suppliers (~60 orders per supplier)
    if i <= 50 * 50:
        sup_id = all_sup_ids[(i - 1) % 50]
    else:
        sup_id = random.choice(all_sup_ids)

    sup_cat = supplier_profiles[sup_id]['category']
    rand_days = random.randint(0, date_range_days)
    order_dt = start_date + timedelta(days=rand_days)

    lead_days = lead_time_pool[i - 1]
    expected_dt = order_dt + timedelta(days=lead_days)

    # Quantity: 100 to 1,000 units
    qty = random.randint(100, 1000)

    # Cost calculation: base unit cost + slight variance
    base_unit_cost = UNIT_COST_BASE[sup_cat]
    cost_variation = random.uniform(0.95, 1.10)
    cost = round(qty * base_unit_cost * cost_variation, 2)

    po_list.append({
        'id': po_id,
        'supplier_id': sup_id,
        'order_date': order_dt.strftime('%Y-%m-%d'),
        'expected_date': expected_dt.strftime('%Y-%m-%d'),
        'qty': qty,
        'cost': cost,
        'lead_time_days': lead_days
    })

df_po = pd.DataFrame(po_list)
df_po = df_po.sort_values(by=['order_date', 'id']).reset_index(drop=True)

po_csv_path = os.path.join(RAW_DATA_DIR, 'purchase_orders.csv')
df_po[['id', 'supplier_id', 'order_date', 'expected_date', 'qty', 'cost']].to_csv(po_csv_path, index=False)
print(f"Generated {len(df_po)} purchase orders -> {po_csv_path}")

# ---------------------------------------------------------
# 3. GENERATE DELIVERIES (3,000 rows)
# Schema: id, order_id, actual_date, status (OnTime/Late), delivered_qty
# Target: ~72.0% OnTime, ~28.0% Late (840 Late deliveries)
# ---------------------------------------------------------
deliveries_list = []
target_total_late = 840

calc_probs = []
for idx, row in df_po.iterrows():
    sup_id = row['supplier_id']
    base_p = supplier_profiles[sup_id]['late_prob']
    lt = row['lead_time_days']

    if lt <= 7:
        lt_mult = 1.05  # rush risk
    elif lt <= 30:
        lt_mult = 0.75  # planned sweet spot
    elif lt <= 90:
        lt_mult = 1.45  # friction horizon
    else:
        lt_mult = 2.30  # high uncertainty horizon

    p = base_p * lt_mult
    calc_probs.append(p)

calc_probs = np.array(calc_probs)
scale = target_total_late / np.sum(calc_probs)
final_probs = np.clip(calc_probs * scale, 0.04, 0.92)

is_late_flags = np.random.rand(len(df_po)) < final_probs
diff = target_total_late - np.sum(is_late_flags)
if diff > 0:
    on_time_indices = np.where(~is_late_flags)[0]
    flip_indices = np.random.choice(on_time_indices, size=diff, replace=False)
    is_late_flags[flip_indices] = True
elif diff < 0:
    late_indices = np.where(is_late_flags)[0]
    flip_indices = np.random.choice(late_indices, size=-diff, replace=False)
    is_late_flags[flip_indices] = False

for i, row in df_po.iterrows():
    del_id = f"DEL{10001 + i}"
    po_id = row['id']
    exp_dt = datetime.strptime(row['expected_date'], '%Y-%m-%d')
    is_late = is_late_flags[i]
    order_qty = row['qty']

    if is_late:
        delay = random.randint(1, 16)
        act_dt = exp_dt + timedelta(days=delay)
        status = 'Late'
    else:
        early_or_exact = random.randint(-8, 0)
        act_dt = exp_dt + timedelta(days=early_or_exact)
        status = 'OnTime'

    # Delivered quantity: occasionally 98%-100% of ordered qty
    delivered_qty = order_qty if random.random() > 0.05 else int(order_qty * random.uniform(0.96, 0.99))

    deliveries_list.append({
        'id': del_id,
        'order_id': po_id,
        'actual_date': act_dt.strftime('%Y-%m-%d'),
        'status': status,
        'delivered_qty': delivered_qty
    })

df_deliveries = pd.DataFrame(deliveries_list)
deliveries_csv_path = os.path.join(RAW_DATA_DIR, 'deliveries.csv')
df_deliveries.to_csv(deliveries_csv_path, index=False)

late_count = (df_deliveries['status'] == 'Late').sum()
late_pct = (late_count / len(df_deliveries)) * 100
print(f"Generated {len(df_deliveries)} deliveries -> {deliveries_csv_path}")
print(f"  Late: {late_count} ({late_pct:.1f}%) | OnTime: {3000 - late_count} ({100 - late_pct:.1f}%)")

# ---------------------------------------------------------
# 4. GENERATE DEFECTS (~780 rows)
# Schema: id, delivery_id, defect_qty, type
# ---------------------------------------------------------
DEFECT_TYPES = [
    'Packaging Damage',
    'Dimensional Non-Conformance',
    'Material Flaw',
    'Missing Documentation',
    'Electrical/Functional Failure'
]
DEFECT_WEIGHTS = [0.28, 0.24, 0.22, 0.14, 0.12]

df_del_merged = df_deliveries.merge(df_po[['id', 'supplier_id']], left_on='order_id', right_on='id')
delivery_defect_probs = [supplier_profiles[sid]['defect_prob'] for sid in df_del_merged['supplier_id']]
norm_weights = np.array(delivery_defect_probs) / sum(delivery_defect_probs)

NUM_DEFECT_DELIVERIES = 780
selected_delivery_indices = np.random.choice(len(df_deliveries), size=NUM_DEFECT_DELIVERIES, replace=False, p=norm_weights)

defects_list = []
for d_num, d_idx in enumerate(selected_delivery_indices, start=1):
    defect_id = f"DEF{10000 + d_num}"
    del_row = df_deliveries.iloc[d_idx]
    del_id = del_row['id']
    del_qty = del_row['delivered_qty']

    max_def = max(4, min(50, int(del_qty * 0.08)))
    defect_qty = random.randint(3, max_def)
    defect_type = random.choices(DEFECT_TYPES, weights=DEFECT_WEIGHTS)[0]

    defects_list.append({
        'id': defect_id,
        'delivery_id': del_id,
        'defect_qty': defect_qty,
        'type': defect_type
    })

df_defects = pd.DataFrame(defects_list)
defects_csv_path = os.path.join(RAW_DATA_DIR, 'defects.csv')
df_defects.to_csv(defects_csv_path, index=False)

total_defect_units = df_defects['defect_qty'].sum()
total_delivered_units = df_deliveries['delivered_qty'].sum()
global_defect_rate = (total_defect_units / total_delivered_units) * 100
print(f"Generated {len(df_defects)} defects -> {defects_csv_path}")
print(f"  Total Defect Units: {total_defect_units:,} / {total_delivered_units:,} ({global_defect_rate:.2f}%)")

print("=" * 80)
print("DATA GENERATION COMPLETED SUCCESSFULLY")
print("=" * 80)

if __name__ == '__main__':
    pass
